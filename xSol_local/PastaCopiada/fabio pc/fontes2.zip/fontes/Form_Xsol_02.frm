VERSION 5.00
Object = "{5E9E78A0-531B-11CF-91F6-C2863C385E30}#1.0#0"; "MSFLXGRD.OCX"
Begin VB.Form Form_Xsol_02 
   BorderStyle     =   0  'None
   Caption         =   "Cadastro de Clientes - XSol"
   ClientHeight    =   8685
   ClientLeft      =   1095
   ClientTop       =   0
   ClientWidth     =   17490
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   8685
   ScaleWidth      =   17490
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Frame5 
      Caption         =   "Atendimento"
      Height          =   1215
      Left            =   6000
      TabIndex        =   71
      Top             =   7320
      Width           =   3135
      Begin VB.CommandButton Cmd_Finaliza 
         Caption         =   "Finalizar Atendimento"
         Height          =   495
         Left            =   1680
         TabIndex        =   73
         Top             =   480
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Atende 
         Caption         =   "A&tende"
         Height          =   495
         Left            =   240
         TabIndex        =   72
         Top             =   480
         Width           =   1215
      End
   End
   Begin VB.Frame Frame4 
      Caption         =   "Edi��o"
      Height          =   1215
      Left            =   120
      TabIndex        =   66
      Top             =   7320
      Width           =   5810
      Begin VB.CommandButton Cmd_Exclui 
         BackColor       =   &H008080FF&
         Caption         =   "E&xclui"
         Height          =   495
         Left            =   4440
         Style           =   1  'Graphical
         TabIndex        =   70
         Top             =   480
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Edita 
         Caption         =   "&Editar"
         Height          =   495
         Left            =   3000
         TabIndex        =   69
         Top             =   480
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Salva 
         Caption         =   "&Salvar"
         Height          =   495
         Left            =   1560
         TabIndex        =   68
         Top             =   480
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Inclui 
         BackColor       =   &H0080FF80&
         Caption         =   "&Incluir"
         Height          =   495
         Left            =   120
         Style           =   1  'Graphical
         TabIndex        =   67
         Top             =   480
         Width           =   1215
      End
   End
   Begin VB.Frame Frame3 
      Caption         =   "Ordena��o"
      Height          =   1575
      Left            =   15360
      TabIndex        =   59
      Top             =   6960
      Width           =   1335
      Begin VB.OptionButton Opt_Sort_Name 
         Caption         =   "Nome"
         Height          =   255
         Left            =   240
         TabIndex        =   61
         Top             =   960
         Width           =   855
      End
      Begin VB.OptionButton Opt_Sort_Code 
         Caption         =   "C�digo"
         Height          =   255
         Left            =   240
         TabIndex        =   60
         Top             =   480
         Width           =   855
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Pesquisa"
      Height          =   1575
      Left            =   9240
      TabIndex        =   52
      Top             =   6960
      Width           =   6015
      Begin VB.CommandButton But_Search_Clean 
         Height          =   495
         Left            =   5280
         Picture         =   "Form_Xsol_02.frx":0000
         Style           =   1  'Graphical
         TabIndex        =   63
         ToolTipText     =   "Limpar"
         Top             =   240
         Width           =   615
      End
      Begin VB.CommandButton But_Search 
         Height          =   495
         Left            =   5280
         Picture         =   "Form_Xsol_02.frx":00A4
         Style           =   1  'Graphical
         TabIndex        =   62
         ToolTipText     =   "Pesquisar"
         Top             =   960
         Width           =   615
      End
      Begin VB.TextBox Txt_Search_Name 
         Height          =   285
         Left            =   960
         TabIndex        =   58
         Top             =   1080
         Width           =   4215
      End
      Begin VB.TextBox Txt_Search_CPF 
         Height          =   285
         Left            =   960
         TabIndex        =   56
         Top             =   720
         Width           =   2055
      End
      Begin VB.TextBox Txt_Search_Code 
         BeginProperty DataFormat 
            Type            =   1
            Format          =   "0"
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1046
            SubFormatType   =   1
         EndProperty
         Height          =   285
         Left            =   960
         TabIndex        =   53
         Top             =   360
         Width           =   2055
      End
      Begin VB.Label Lbl_Search_Name 
         Alignment       =   1  'Right Justify
         Caption         =   "Nome:"
         Height          =   255
         Left            =   120
         TabIndex        =   57
         Top             =   1080
         Width           =   615
      End
      Begin VB.Label Lbl_Search_CPF 
         Alignment       =   1  'Right Justify
         Caption         =   "CPF:"
         Height          =   255
         Left            =   360
         TabIndex        =   55
         Top             =   720
         Width           =   375
      End
      Begin VB.Label Lbl_Search_Code 
         Alignment       =   1  'Right Justify
         Caption         =   "C�digo:"
         Height          =   255
         Left            =   120
         TabIndex        =   54
         Top             =   360
         Width           =   615
      End
   End
   Begin VB.CommandButton But_Close 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   16800
      Picture         =   "Form_Xsol_02.frx":0187
      Style           =   1  'Graphical
      TabIndex        =   51
      Top             =   7080
      UseMaskColor    =   -1  'True
      Width           =   525
   End
   Begin VB.Frame Frame1 
      Caption         =   "Lista de Clientes"
      Height          =   6855
      Left            =   9240
      TabIndex        =   49
      Top             =   120
      Width           =   8055
      Begin MSFlexGridLib.MSFlexGrid Grid_Customer 
         Height          =   6375
         Left            =   120
         TabIndex        =   50
         Top             =   360
         Width           =   7815
         _ExtentX        =   13785
         _ExtentY        =   11245
         _Version        =   393216
         Rows            =   1
         Cols            =   5
         FixedRows       =   0
         FixedCols       =   0
         SelectionMode   =   1
      End
   End
   Begin VB.Frame Frame_Cliente 
      Caption         =   "Dados do Cliente"
      Height          =   7170
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   9015
      Begin VB.TextBox Txt_Next_Visit 
         BackColor       =   &H8000000F&
         Enabled         =   0   'False
         Height          =   285
         Left            =   2880
         TabIndex        =   65
         Top             =   6720
         Width           =   1215
      End
      Begin VB.TextBox Text_Cod 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         Height          =   285
         Left            =   2880
         TabIndex        =   48
         Top             =   1320
         Width           =   2655
      End
      Begin VB.TextBox Text_Registro 
         Alignment       =   2  'Center
         Enabled         =   0   'False
         Height          =   285
         Left            =   8160
         TabIndex        =   46
         Top             =   240
         Width           =   735
      End
      Begin VB.TextBox Text_Cnpj 
         Height          =   285
         Left            =   2880
         TabIndex        =   2
         Top             =   960
         Width           =   2655
      End
      Begin VB.TextBox Text_Dt_Contrato 
         Height          =   285
         Left            =   5400
         TabIndex        =   19
         Top             =   6360
         Width           =   1095
      End
      Begin VB.TextBox Text_Contrato 
         Height          =   285
         Left            =   2880
         TabIndex        =   18
         Top             =   6360
         Width           =   1215
      End
      Begin VB.ComboBox Combo_Solicitante 
         Height          =   315
         Left            =   2880
         Style           =   2  'Dropdown List
         TabIndex        =   17
         Top             =   6000
         Width           =   4335
      End
      Begin VB.TextBox Text_Solicitante 
         Height          =   285
         Left            =   2880
         TabIndex        =   39
         Top             =   6000
         Width           =   4215
      End
      Begin VB.ComboBox Combo_Zona 
         Height          =   315
         Left            =   2880
         Style           =   2  'Dropdown List
         TabIndex        =   11
         Top             =   3840
         Width           =   2775
      End
      Begin VB.ComboBox Combo_Uf 
         Height          =   315
         Left            =   2880
         Style           =   2  'Dropdown List
         TabIndex        =   8
         Top             =   3120
         Width           =   615
      End
      Begin VB.TextBox Text_NomeCli 
         Height          =   285
         Left            =   2880
         TabIndex        =   4
         Top             =   1680
         Width           =   4575
      End
      Begin VB.TextBox Text_End 
         Height          =   285
         Left            =   2880
         TabIndex        =   5
         Top             =   2040
         Width           =   4575
      End
      Begin VB.TextBox Text_Dt_Emis 
         Height          =   285
         Left            =   2880
         TabIndex        =   22
         Top             =   240
         Width           =   975
      End
      Begin VB.TextBox Text_Cpf 
         Height          =   285
         Left            =   2880
         TabIndex        =   1
         Top             =   600
         Width           =   2295
      End
      Begin VB.TextBox Text_Bairro 
         Height          =   285
         Left            =   2880
         TabIndex        =   6
         Top             =   2400
         Width           =   4575
      End
      Begin VB.TextBox Text_Cidade 
         Height          =   285
         Left            =   2880
         TabIndex        =   7
         Top             =   2760
         Width           =   4575
      End
      Begin VB.TextBox Text_Uf 
         Height          =   285
         Left            =   2880
         TabIndex        =   21
         Top             =   3120
         Width           =   375
      End
      Begin VB.TextBox Text_Cep 
         Height          =   285
         Left            =   4080
         TabIndex        =   9
         Top             =   3120
         Width           =   1455
      End
      Begin VB.TextBox Text_Ref 
         Height          =   285
         Left            =   2880
         TabIndex        =   10
         Top             =   3480
         Width           =   4455
      End
      Begin VB.TextBox Text_Zona 
         Height          =   285
         Left            =   2880
         TabIndex        =   20
         Top             =   3840
         Width           =   2775
      End
      Begin VB.TextBox Text_Fone_Resid 
         Height          =   285
         Left            =   2880
         TabIndex        =   12
         Top             =   4200
         Width           =   2535
      End
      Begin VB.TextBox Text_Fone_Com 
         Height          =   285
         Left            =   2880
         TabIndex        =   13
         Top             =   4560
         Width           =   2535
      End
      Begin VB.TextBox Text_Celular 
         Height          =   285
         Left            =   2880
         TabIndex        =   14
         Top             =   4920
         Width           =   2535
      End
      Begin VB.TextBox Text_E_Mail 
         Height          =   285
         Left            =   2880
         TabIndex        =   15
         Top             =   5280
         Width           =   2535
      End
      Begin VB.TextBox Text_Tipo_Equip 
         Height          =   285
         Left            =   2880
         TabIndex        =   16
         Top             =   5640
         Width           =   5775
      End
      Begin VB.TextBox Text_Atendente 
         Height          =   285
         Left            =   6240
         TabIndex        =   3
         Top             =   600
         Width           =   1215
      End
      Begin VB.Label Lbl_Dt_Visita 
         Alignment       =   1  'Right Justify
         Caption         =   "Data Pr�xima Visita:"
         Height          =   255
         Left            =   1200
         TabIndex        =   64
         Top             =   6720
         Width           =   1575
      End
      Begin VB.Label Lbl_Cod 
         Alignment       =   1  'Right Justify
         Caption         =   "C�digo do Cliente:"
         Height          =   255
         Left            =   1440
         TabIndex        =   47
         Top             =   1320
         Width           =   1335
      End
      Begin VB.Label Lbl_Registro 
         Alignment       =   1  'Right Justify
         Caption         =   "Registro:"
         Height          =   255
         Left            =   7440
         TabIndex        =   45
         Top             =   240
         Width           =   615
      End
      Begin VB.Label Label2 
         Alignment       =   1  'Right Justify
         Caption         =   "ou"
         Height          =   255
         Left            =   2160
         TabIndex        =   44
         Top             =   720
         Width           =   255
      End
      Begin VB.Label Lbl_Cnpj 
         Alignment       =   1  'Right Justify
         Caption         =   "Cnpj:"
         Height          =   255
         Left            =   2280
         TabIndex        =   43
         Top             =   960
         Width           =   495
      End
      Begin VB.Label Lbl_Dt_Contrato 
         Alignment       =   1  'Right Justify
         Caption         =   "Dt. Contrato:"
         Height          =   255
         Left            =   4320
         TabIndex        =   42
         Top             =   6360
         Width           =   975
      End
      Begin VB.Label Lbl_Contrato 
         Alignment       =   1  'Right Justify
         Caption         =   "Contrato:"
         Height          =   255
         Left            =   2040
         TabIndex        =   41
         Top             =   6360
         Width           =   735
      End
      Begin VB.Label Llb_Solitante 
         Alignment       =   1  'Right Justify
         Caption         =   "Empresa solicitante:"
         Height          =   255
         Left            =   1200
         TabIndex        =   40
         Top             =   6000
         Width           =   1575
      End
      Begin VB.Label Lbl_Nome 
         Alignment       =   1  'Right Justify
         Caption         =   "Nome do Cliente / Raz�o Social:"
         Height          =   255
         Left            =   360
         TabIndex        =   38
         Top             =   1680
         Width           =   2415
      End
      Begin VB.Label Lbl_End 
         Alignment       =   1  'Right Justify
         Caption         =   "Endere�o:"
         Height          =   255
         Left            =   2040
         TabIndex        =   37
         Top             =   2040
         Width           =   735
      End
      Begin VB.Label Lbl_Dt_Emis 
         Alignment       =   1  'Right Justify
         Caption         =   "Data Emiss�o:"
         Height          =   255
         Left            =   1680
         TabIndex        =   36
         Top             =   240
         Width           =   1095
      End
      Begin VB.Label Lbl_Cpf 
         Alignment       =   1  'Right Justify
         Caption         =   "Cpf:"
         Height          =   255
         Left            =   2400
         TabIndex        =   35
         Top             =   600
         Width           =   375
      End
      Begin VB.Label Lbl_Bairro 
         Alignment       =   1  'Right Justify
         Caption         =   "Bairro:"
         Height          =   255
         Left            =   2280
         TabIndex        =   34
         Top             =   2400
         Width           =   495
      End
      Begin VB.Label Lbl_Cidade 
         Alignment       =   1  'Right Justify
         Caption         =   "Cidade:"
         Height          =   255
         Left            =   2160
         TabIndex        =   33
         Top             =   2760
         Width           =   615
      End
      Begin VB.Label Lbl_Uf 
         Alignment       =   1  'Right Justify
         Caption         =   "Uf:"
         Height          =   255
         Left            =   2520
         TabIndex        =   32
         Top             =   3120
         Width           =   255
      End
      Begin VB.Label Lbl_Cep 
         Alignment       =   1  'Right Justify
         Caption         =   "Cep:"
         Height          =   255
         Left            =   3600
         TabIndex        =   31
         Top             =   3120
         Width           =   375
      End
      Begin VB.Label Lbl_Ref 
         Alignment       =   1  'Right Justify
         Caption         =   "Refer�ncia:"
         Height          =   255
         Left            =   1920
         TabIndex        =   30
         Top             =   3480
         Width           =   855
      End
      Begin VB.Label Lbl_Zona 
         Alignment       =   1  'Right Justify
         Caption         =   "Zona:"
         Height          =   255
         Left            =   2280
         TabIndex        =   29
         Top             =   3840
         Width           =   495
      End
      Begin VB.Label Lbl_Fone_Resid 
         Alignment       =   1  'Right Justify
         Caption         =   "Fone Resid:"
         Height          =   255
         Left            =   1920
         TabIndex        =   28
         Top             =   4200
         Width           =   855
      End
      Begin VB.Label Lbl_Fone_Com 
         Alignment       =   1  'Right Justify
         Caption         =   "Fone Com.:"
         Height          =   255
         Left            =   1920
         TabIndex        =   27
         Top             =   4560
         Width           =   855
      End
      Begin VB.Label Lbl_Celular 
         Alignment       =   1  'Right Justify
         Caption         =   "Celular:"
         Height          =   255
         Left            =   2160
         TabIndex        =   26
         Top             =   4920
         Width           =   615
      End
      Begin VB.Label Lbl_E_Mail 
         Alignment       =   1  'Right Justify
         Caption         =   "E-Mail:"
         Height          =   255
         Left            =   2280
         TabIndex        =   25
         Top             =   5280
         Width           =   495
      End
      Begin VB.Label Lbl_Tipo_Eq 
         Alignment       =   1  'Right Justify
         Caption         =   "Tipo de Equip / Modelo:"
         Height          =   255
         Left            =   960
         TabIndex        =   24
         Top             =   5640
         Width           =   1815
      End
      Begin VB.Label Lbl_Atendente 
         Alignment       =   1  'Right Justify
         Caption         =   "Atendente:"
         Height          =   255
         Left            =   5280
         TabIndex        =   23
         Top             =   600
         Width           =   855
      End
   End
End
Attribute VB_Name = "Form_Xsol_02"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public W_DB As Connection
Private conn As ADODB.Connection
Public Tabela_Clientes As Recordset
Public Tabela_Empresas As Recordset

Private Sub But_Close_Click()

    Unload Me

End Sub

Private Sub But_Search_Clean_Click()
    Txt_Search_Code.Text = ""
    Txt_Search_CPF.Text = ""
    Txt_Search_Name.Text = ""
End Sub

Private Sub But_Search_Click()
    With Grid_Customer
        Call Fill_Grid(Return_Recordset(Return_SqlString(3, Txt_Search_Code.Text, Txt_Search_CPF.Text, Txt_Search_Name.Text)))
    End With
End Sub

Private Sub Cmd_Atende_Click()
    Cod_Cli = CInt(Text_Cod.Text)
    Nome_Cli_Atend = Text_NomeCli.Text
    
    Form_Xsol_05.Show vbModal
End Sub

Private Sub Cmd_Edita_Click()

    If Cmd_Edita.Caption = "&Editar" Then
            
        Cmd_Edita.Caption = "&Cancela"
    
        Cmd_Inclui.enabled = False
        
        Call DesabilitaNavegacao
        Call Destrava_Registro
        Call Cad_Ed
               
        Text_NomeCli.SetFocus
        
    ElseIf Cmd_Edita.Caption = "&Cancela" Then
        Cmd_Edita.Caption = "&Editar"
        
        Cmd_Inclui.enabled = True
        
        Call Grid_Customer_Click
        
        Call HabilitaNavegacao
        Call Cad_Ed_Fim
        Call Trava_Registro
    End If

End Sub

Private Sub Cmd_Exclui_Click()

    If MsgBox("Confirma a Exclus�o do Cliente " & Text_NomeCli.Text & " ? ", vbYesNo, "Excluir Registros") = vbYes Then
        Call Return_Recordset(Return_SqlString(2, Text_Cod.Text)).Delete
        With Grid_Customer
            Call Fill_Grid(Return_Recordset(Return_SqlString(3, Txt_Search_Code.Text, Txt_Search_CPF.Text, Txt_Search_Name.Text)))
        End With
    End If
End Sub

Private Sub Cmd_Finaliza_Click()
    Cod_Cli = CInt(Text_Cod.Text)
    Nome_Cli_Atend = Text_NomeCli.Text

    Form_Xsol_06.Show vbModal
End Sub

Private Sub Cmd_Inclui_Click()

Call Cad_Ed

If Cmd_Inclui.Caption = "&Incluir" Then
   
   Cmd_Inclui.Caption = "&Cancela"
   
   Cmd_Edita.enabled = False
   
   Call DesabilitaNavegacao
   Call LimpaControles
   Call Destrava_Registro
   
   Text_NomeCli.SetFocus
   
ElseIf Cmd_Inclui.Caption = "&Cancela" Then
   
   Cmd_Inclui.Caption = "&Incluir"
   
   Cmd_Edita.enabled = True
   
   Call Grid_Customer_Click
   Call HabilitaNavegacao
   Call Trava_Registro
   
   Call Cad_Ed_Fim

End If

End Sub

Private Sub Cmd_Salva_Click()
    Dim rs As ADODB.Recordset
    
    If Not Fill_Mandatory_Fields Then
        Exit Sub
    End If
    
    If Cmd_Inclui.Caption = "&Cancela" Then
        Set rs = Return_Recordset(Return_SqlString(4))
        rs.AddNew
        Text_Cod.Text = rs.Fields("codigo")
    Else
        Set rs = Return_Recordset(Return_SqlString(2, Text_Cod.Text))
    End If

    Call Record_Record(rs)

    rs.Update

    rs.Close
    Set rs = Nothing
    
    Call Trava_Registro
    Call HabilitaNavegacao
    
    If Cmd_Inclui.Caption = "&Cancela" Then
       Cmd_Inclui.Caption = "&Incluir"
    End If
        
    If Cmd_Edita.Caption = "&Cancela" Then
       Cmd_Edita.Caption = "&Editar"
    End If
     
    Call Cad_Ed_Fim
    Cmd_Salva.enabled = False
    Cmd_Edita.enabled = True
    Cmd_Inclui.enabled = True
    Cmd_Exclui.enabled = True
    
    With Grid_Customer
        Call Fill_Grid(Return_Recordset(Return_SqlString(3, Txt_Search_Code.Text, Txt_Search_CPF.Text, Txt_Search_Name.Text)), Text_Cod.Text)
    End With
End Sub

Private Function Fill_Mandatory_Fields() As Boolean
    
    Fill_Mandatory_Fields = True
    
    If Trim(Text_NomeCli.Text) = "" Then
       MsgBox "� necess�rio digitar o Nome do Cliente / Raz�o Social! ", vbOKOnly, "XSol Arte em Aquecedores"
       Text_NomeCli.SetFocus
       Fill_Mandatory_Fields = False
       Exit Function
    End If
        
    If Trim(Text_End.Text) = "" Then
       MsgBox "� necess�rio digitar o Endere�o! ", vbOKOnly, "XSol Arte em Aquecedores"
       Text_End.SetFocus
       Fill_Mandatory_Fields = False
       Exit Function
    End If
    
    If Trim(Text_Bairro.Text) = "" Then
       MsgBox "� necess�rio digitar o Bairro! ", vbOKOnly, "XSol Arte em Aquecedores"
       Text_Bairro.SetFocus
       Fill_Mandatory_Fields = False
       Exit Function
    End If
    
    If Trim(Text_Cidade.Text) = "" Then
       MsgBox "� necess�rio digitar Cidade! ", vbOKOnly, "XSol Arte em Aquecedores"
       Text_Cidade.SetFocus
       Fill_Mandatory_Fields = False
       Exit Function
    End If
    
    If Combo_Uf.Text = "" And Text_Uf.Text = "" Then
       MsgBox "� necess�rio selecionar a Unidade Federativa! ", vbOKOnly, "XSol Arte em Aquecedores"
       Combo_Uf.SetFocus
       Fill_Mandatory_Fields = False
       Exit Function
    End If
    
    If Combo_Zona.Text = "" And Text_Zona.Text = "" Then
       MsgBox "� necess�rio selecionar a ZONA! ", vbOKOnly, "XSol Arte em Aquecedores"
       Combo_Zona.SetFocus
       Fill_Mandatory_Fields = False
       Exit Function
    End If
    
    If Combo_Solicitante.Text = "" And Text_Solicitante.Text = "" Then
      MsgBox "� necess�rio selecionar o Solicitante! ", vbOKOnly, "XSol Arte em Aquecedores"
       Combo_Solicitante.SetFocus
       Fill_Mandatory_Fields = False
       Exit Function
    End If

End Function

Private Sub Combo_Solicitante_Click()

Text_Solicitante.Text = Combo_Solicitante.Text

End Sub
Private Sub Combo_Solicitante_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
   Text_Solicitante.Text = Combo_Solicitante.Text
End If

End Sub

Private Sub Combo_Uf_Click()

Text_Uf.Text = Combo_Uf.Text

End Sub

Private Sub Combo_Uf_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
   Text_Uf.Text = Combo_Uf.Text
End If

End Sub
Private Sub Combo_Zona_Click()

Text_Zona.Text = Combo_Zona.Text

End Sub

Private Sub Combo_Zona_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
   Text_Zona.Text = Combo_Zona.Text
End If

End Sub

Private Sub Form_Load()

Dim hMenu As Long
Dim lItemCount As Long

hMenu = GetSystemMenu(Me.hWnd, 0)
If hMenu Then
   lItemCount = GetMenuItemCount(hMenu)
   Call RemoveMenu(hMenu, lItemCount - 1, MF_REMOVE Or _
   MF_BYPOSITION)
    Call RemoveMenu(hMenu, lItemCount - 2, MF_REMOVE Or _
    MF_BYPOSITION)
   Call DrawMenuBar(Me.hWnd)
End If

Call Ajusta_Form(Me)

Text_NomeCli.MaxLength = 80
Text_Cpf.MaxLength = 15
Text_Cnpj.MaxLength = 25
Text_Atendente.MaxLength = 20
Text_End.MaxLength = 70
Text_Bairro.MaxLength = 50
Text_Cidade.MaxLength = 50
Text_Uf.MaxLength = 2
Text_Cep.MaxLength = 11
Text_Ref.MaxLength = 70
Text_Zona.MaxLength = 20
Text_Fone_Resid.MaxLength = 25
Text_Fone_Com.MaxLength = 25
Text_Celular.MaxLength = 25
Text_E_Mail.MaxLength = 50
Text_Solicitante.MaxLength = 50
Text_Contrato.MaxLength = 25

Call Arquivos_Dados

Set W_DB = New Connection

Set Tabela_Clientes = New Recordset

Set conn = New ADODB.Connection
conn.Open "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" & W_DBname & ";"
    
W_DB.Mode = adModeReadWrite

W_DB.Open "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" & W_DBname & ";"

Tabela_Clientes.Open "select * from Clientes Order By Codigo ", W_DB, adOpenStatic, adLockOptimistic

Set Tabela_Empresas = New Recordset
Tabela_Empresas.Open "select Tipo_Cliente from Empresa Order By Tipo_Cliente ", W_DB, adOpenStatic, adLockOptimistic

Form_Xsol_02.Caption = "Cadastro de Clientes Xsol"
Text_Dt_Emis.enabled = False

Call Trava_Registro

Call Configure_Controls
Call Configure_Grid
Call Fill_Grid(Return_Recordset(Return_SqlString(1)))

End Sub

Private Sub Configure_Controls()
    Opt_Sort_Code.Value = True
End Sub

Private Sub Configure_Grid()

    With Grid_Customer
        .Cols = 4
        .FixedCols = 0
        .ColWidth(0) = 650
        .ColWidth(1) = 4000
        .ColWidth(2) = 1500
        .ColWidth(3) = 1300
        .ColAlignment(0) = flexAlignCenterCenter
        .ColAlignment(1) = flexAlignLeftCenter
        .ColAlignment(2) = flexAlignLeftCenter
        .ColAlignment(3) = flexAlignLeftCenter
        .SelectionMode = flexSelectionByRow
        .HighLight = flexHighlightAlways
        .Rows = 2
        .FixedRows = 1
        .TextMatrix(0, 0) = "C�digo"
        .TextMatrix(0, 1) = "Nome"
        .TextMatrix(0, 2) = "CPF"
        .TextMatrix(0, 3) = "Celular"
        .RowHeight(1) = 0
    End With
    
End Sub

' queryType = 1 => all
'           = 2 => by codigo
'           = 3 => by codigo, cpf or name

Private Function Return_SqlString(queryType As Integer, Optional param1 As String, Optional param2 As String, Optional param3 As String) As String
    Dim whereClause As String
    
    If queryType = 1 Then
        Return_SqlString = "SELECT codigo,nome_cli,cpf,fone_celular FROM Clientes"
    ElseIf queryType = 2 Then
        Return_SqlString = "SELECT * FROM Clientes WHERE codigo = " & param1
    ElseIf queryType = 3 Then
        Return_SqlString = "SELECT codigo,nome_cli,cpf,fone_celular FROM Clientes"
        If param1 <> "" Then
            whereClause = " WHERE codigo = " & param1
        End If
        If param2 <> "" Then
            If whereClause <> "" Then
                whereClause = whereClause & " AND "
            Else
                whereClause = " WHERE "
            End If
            whereClause = whereClause & "cpf LIKE '%" & param2 & "%'"
        End If
        If param3 <> "" Then
            If whereClause <> "" Then
                whereClause = whereClause & " AND "
            Else
                whereClause = " WHERE "
            End If
            whereClause = whereClause & "nome_cli LIKE '%" & param3 & "%'"
        End If
        Return_SqlString = Return_SqlString + whereClause
    ElseIf queryType = 4 Then
        Return_SqlString = "SELECT * FROM Clientes"
    ElseIf queryType = 5 Then
        Return_SqlString = "SELECT * FROM Atendimento WHERE cod_cliente = " & param1
    ElseIf queryType = 6 Then
        Return_SqlString = "SELECT * FROM Visitas WHERE dt_expiracao IS NULL AND cod_cliente = " & param1
    End If

    If queryType <= 4 Then
        If Opt_Sort_Code.Value Then
            Return_SqlString = Return_SqlString + " ORDER BY Codigo"
        ElseIf Opt_Sort_Name Then
            Return_SqlString = Return_SqlString + " ORDER BY Nome_Cli"
        End If
    End If
End Function

Private Function Return_Recordset(strSql As String) As ADODB.Recordset
    Dim rs As New ADODB.Recordset
    
    rs.Open strSql, conn, adOpenStatic, adLockOptimistic
    
    Set Return_Recordset = rs
End Function

Private Sub Fill_Grid(rs As ADODB.Recordset, Optional code As String)
    'Dim count As Integer
    Dim selectedRow As Integer
    
    'count = 2
    selectedRow = 2
    With Grid_Customer
        .Rows = 2
        Do Until rs.EOF
            .AddItem (rs.Fields("codigo") & vbTab & IIf(IsNull(rs.Fields("Nome_Cli")), "", rs.Fields("Nome_Cli")) & vbTab & IIf(IsNull(rs.Fields("cpf")), "", rs.Fields("cpf")) & vbTab & rs.Fields("fone_celular"))
            If code <> "" Then
                If code = rs.Fields("codigo") Then
                    'selectedRow = count
                    selectedRow = .Rows - 1
                End If
                'count = count + 1
            End If
            rs.MoveNext
        Loop
        
        .Refresh
        If rs.RecordCount > 0 Then
            .Row = selectedRow
            .RowSel = selectedRow
            .TopRow = selectedRow
            .col = 0
            .ColSel = .Cols - 1
            Call Grid_Customer_Click
            Cmd_Edita.enabled = True
            Cmd_Exclui.enabled = True
        Else
            Cmd_Edita.enabled = False
            Cmd_Exclui.enabled = False
            Cmd_Atende.enabled = False
            Cmd_Finaliza.enabled = False
            Call LimpaControles
        End If
    End With
    
    Text_Registro.Text = rs.RecordCount
    rs.Close
    Set rs = Nothing
End Sub

Sub Show_Record(rs As ADODB.Recordset)

    If rs.EOF Or rs.BOF Then
       Exit Sub
    End If

    Text_Dt_Emis.Text = IIf(IsNull(rs.Fields("Data_Emissao")), "", rs.Fields("Data_Emissao"))
    
    Text_Cod.Text = UCase(IIf(IsNull(rs.Fields("Codigo")), "", rs.Fields("Codigo")))
    
    Text_NomeCli.Text = UCase(IIf(IsNull(rs.Fields("Nome_Cli")), "", rs.Fields("Nome_Cli")))
    
    Text_Cpf.Text = IIf(IsNull(rs.Fields("CPF")), "", rs.Fields("CPF"))
    
    Text_Cnpj.Text = IIf(IsNull(rs.Fields("CNPJ")), "", rs.Fields("CNPJ"))
    
    Text_Atendente.Text = UCase(IIf(IsNull(rs.Fields("Atendente")), "", rs.Fields("Atendente")))
    
    Text_End.Text = UCase(IIf(IsNull(rs.Fields("End")), "", rs.Fields("End")))
    
    Text_Bairro.Text = UCase(IIf(IsNull(rs.Fields("Bairro")), "", rs.Fields("Bairro")))
    
    Text_Cidade.Text = UCase(IIf(IsNull(rs.Fields("Cidade")), "", rs.Fields("Cidade")))
    
    Text_Uf.Text = UCase(IIf(IsNull(rs.Fields("Uf")), "", rs.Fields("Uf")))
    
    Text_Cep.Text = IIf(IsNull(rs.Fields("Cep")), "", rs.Fields("Cep"))
    
    Text_Ref.Text = UCase(IIf(IsNull(rs.Fields("Ref")), "", rs.Fields("Ref")))
    
    Text_Zona.Text = UCase(IIf(IsNull(rs.Fields("Zona")), "", rs.Fields("Zona")))
    
    Text_Fone_Resid.Text = IIf(IsNull(rs.Fields("Fone_Res")), "", rs.Fields("Fone_Res"))
    
    Text_Fone_Com.Text = IIf(IsNull(rs.Fields("Fone_Com")), "", rs.Fields("Fone_Com"))
    
    Text_Celular.Text = IIf(IsNull(rs.Fields("Fone_Celular")), "", rs.Fields("Fone_Celular"))
    
    Text_E_Mail.Text = IIf(IsNull(rs.Fields("E_Mail")), "", rs.Fields("E_Mail"))
    
    Text_Tipo_Equip.Text = UCase(IIf(IsNull(rs.Fields("Tipo_Eq_Mod")), "", rs.Fields("Tipo_Eq_Mod")))
    
    Text_Solicitante.Text = UCase(IIf(IsNull(rs.Fields("Solicitante")), "", rs.Fields("Solicitante")))
    
    Text_Contrato.Text = IIf(IsNull(rs.Fields("Contrato")), "", rs.Fields("Contrato"))
    
    Text_Dt_Contrato.Text = IIf(IsNull(rs.Fields("Dt_Contrato")), "", rs.Fields("Dt_Contrato"))
    
    Txt_Next_Visit.Text = GET_CLIENT_NEXT_VISIT(rs.Fields("Codigo"))

    rs.Close
    Set rs = Nothing
End Sub

Private Function GET_CLIENT_NEXT_VISIT(codigo As String) As String
    Dim rs As ADODB.Recordset
    
    Set rs = Return_Recordset(Return_SqlString(6, codigo))
    If rs.RecordCount > 0 Then
        GET_CLIENT_NEXT_VISIT = rs.Fields("dt_prox_visita")
    Else
        GET_CLIENT_NEXT_VISIT = ""
    End If
End Function

Sub Trava_Registro()

Cmd_Salva.enabled = False
Combo_Zona.Visible = False
Combo_Uf.Visible = False
Combo_Solicitante.Visible = False

Text_NomeCli.Locked = True
Text_Cpf.Locked = True
Text_Cnpj.Locked = True
Text_Atendente.Locked = True
Text_End.Locked = True
Text_Bairro.Locked = True
Text_Cidade.Locked = True
Text_Uf.Locked = True
Text_Cep.Locked = True
Text_Ref.Locked = True
Text_Zona.Locked = True
Text_Fone_Resid.Locked = True
Text_Fone_Com.Locked = True
Text_Celular.Locked = True
Text_E_Mail.Locked = True
Text_Tipo_Equip.Locked = True
Text_Solicitante.Locked = True
Text_Contrato.Locked = True
Text_Dt_Contrato.Locked = True

End Sub

Sub Destrava_Registro()

Cmd_Salva.enabled = True
Combo_Zona.Visible = True
Combo_Uf.Visible = True
Combo_Solicitante.Visible = True

Text_NomeCli.Locked = False
Text_Cpf.Locked = False
Text_Cnpj.Locked = False
Text_Atendente.Locked = False
Text_End.Locked = False
Text_Bairro.Locked = False
Text_Cidade.Locked = False
Text_Uf.Locked = False
Text_Cep.Locked = False
Text_Ref.Locked = False
Text_Zona.Locked = False
Text_Fone_Resid.Locked = False
Text_Fone_Com.Locked = False
Text_Celular.Locked = False
Text_E_Mail.Locked = False
Text_Tipo_Equip.Locked = False
Text_Solicitante.Locked = False
Text_Contrato.Locked = False
Text_Dt_Contrato.Locked = False

End Sub

Sub LimpaControles()

Text_Dt_Emis.Text = ""
Text_Cod.Text = ""
Text_NomeCli.Text = ""
Text_Cpf.Text = ""
Text_Cnpj.Text = ""
Text_Atendente.Text = ""
Text_End.Text = ""
Text_Bairro.Text = ""
Text_Cidade.Text = ""
Text_Uf.Text = ""
Text_Cep.Text = ""
Text_Ref.Text = ""
Text_Zona.Text = ""
Text_Fone_Resid.Text = ""
Text_Fone_Com.Text = ""
Text_Celular.Text = ""
Text_E_Mail.Text = ""
Text_Tipo_Equip.Text = ""
Text_Contrato.Text = ""
Text_Solicitante.Text = ""
Text_Dt_Contrato.Text = ""

End Sub

Private Sub Record_Record(rs As ADODB.Recordset)
            
   rs.Fields("Data_Emissao").Value = Date
   
   If Trim(Text_NomeCli.Text) = "" Then
      rs.Fields("Nome_Cli").Value = Null
   Else
      rs.Fields("Nome_Cli").Value = Text_NomeCli.Text
   End If
   
   If Trim(Text_Cpf.Text) = "" Then
      rs.Fields("CPF").Value = Null
   Else
      rs.Fields("CPF").Value = Text_Cpf.Text
   End If
   
   If Trim(Text_Cnpj.Text) = "" Then
      rs.Fields("CNPJ").Value = Null
   Else
      rs.Fields("CNPJ").Value = Text_Cnpj.Text
   End If
   
   If Trim(Text_Atendente.Text) = "" Then
      rs.Fields("Atendente").Value = Null
   Else
      rs.Fields("Atendente").Value = Text_Atendente.Text
   End If
      
   If Trim(Text_End.Text) = "" Then
      rs.Fields("End").Value = Null
   Else
      rs.Fields("End").Value = Text_End.Text
   End If
   
   If Trim(Text_Bairro.Text) = "" Then
      rs.Fields("Bairro").Value = Null
   Else
      rs.Fields("Bairro").Value = Text_Bairro.Text
   End If
   
   If Trim(Text_Cidade.Text) = "" Then
      rs.Fields("Cidade").Value = Null
   Else
      rs.Fields("Cidade").Value = Text_Cidade.Text
   End If
   
   If Trim(Text_Uf.Text) = "" Then
      rs.Fields("Uf").Value = Null
   Else
      rs.Fields("Uf").Value = Text_Uf.Text
   End If
   
   If Trim(Text_Cep.Text) = "" Then
      rs.Fields("Cep").Value = Null
   Else
      rs.Fields("Cep").Value = Text_Cep.Text
   End If
   
   If Trim(Text_Ref.Text) = "" Then
      rs.Fields("Ref").Value = Null
   Else
      rs.Fields("Ref").Value = Text_Ref.Text
   End If
   
   If Trim(Text_Zona.Text) = "" Then
      rs.Fields("Zona").Value = Null
   Else
      rs.Fields("Zona").Value = Text_Zona.Text
   End If
   
   If Trim(Text_Fone_Resid.Text) = "" Then
      rs.Fields("Fone_Res").Value = Null
   Else
      rs.Fields("Fone_Res").Value = Text_Fone_Resid.Text
   End If
   
   If Trim(Text_Fone_Com.Text) = "" Then
      rs.Fields("Fone_Com").Value = Null
   Else
      rs.Fields("Fone_Com").Value = Text_Fone_Com.Text
   End If
   
   If Trim(Text_Celular.Text) = "" Then
      rs.Fields("Fone_Celular").Value = Null
   Else
      rs.Fields("Fone_Celular").Value = Text_Celular.Text
   End If
   
   If Trim(Text_E_Mail.Text) = "" Then
      rs.Fields("E_Mail").Value = Null
   Else
      rs.Fields("E_Mail").Value = Text_E_Mail.Text
   End If
   
   If Trim(Text_Tipo_Equip.Text) = "" Then
      rs.Fields("Tipo_Eq_Mod").Value = Null
   Else
      rs.Fields("Tipo_Eq_Mod").Value = Text_Tipo_Equip.Text
   End If
   
   If Trim(Text_Tipo_Equip.Text) = "" Then
      rs.Fields("Tipo_Eq_Mod").Value = Null
   Else
      rs.Fields("Tipo_Eq_Mod").Value = Text_Tipo_Equip.Text
   End If
   
   If Trim(Text_Solicitante.Text) = "" Then
      rs.Fields("Solicitante").Value = Null
   Else
      rs.Fields("Solicitante").Value = Text_Solicitante.Text
   End If
   
  If Trim(Text_Contrato.Text) = "" Then
      rs.Fields("Contrato").Value = Null
   Else
      rs.Fields("Contrato").Value = Text_Contrato.Text
   End If
   
   If Trim(Text_Dt_Contrato.Text) = "" Then
      rs.Fields("Dt_Contrato").Value = Null
   Else
      rs.Fields("Dt_Contrato").Value = Text_Dt_Contrato.Text
   End If
   
End Sub

Sub DesabilitaNavegacao()

   'Cmd_Fechar.Enabled = False
   But_Close.enabled = False
   'Cmd_Busca_1.Enabled = False
   Cmd_Atende.enabled = False
'   Cmd_Primeiro.Enabled = False
'   Cmd_Anterior.Enabled = False
'   Cmd_Proximo.Enabled = False
'   Cmd_Ultimo.Enabled = False
   Cmd_Finaliza.enabled = False
   Cmd_Exclui.enabled = False
   
   But_Search_Clean.enabled = False
   But_Search.enabled = False
   Txt_Search_Code.enabled = False
   Txt_Search_CPF.enabled = False
   Txt_Search_Name.enabled = False
   Opt_Sort_Code.enabled = False
   Opt_Sort_Name.enabled = False
   Grid_Customer.enabled = False
End Sub

Sub HabilitaNavegacao()

   'Cmd_Fechar.Enabled = True
   But_Close.enabled = True
   'Cmd_Busca_1.Enabled = True
   Cmd_Atende.enabled = True
'   Cmd_Primeiro.Enabled = True
'   Cmd_Anterior.Enabled = True
'   Cmd_Proximo.Enabled = True
'   Cmd_Ultimo.Enabled = True
   Cmd_Finaliza.enabled = True
   Cmd_Exclui.enabled = True
   
   But_Search_Clean.enabled = True
   But_Search.enabled = True
   Txt_Search_Code.enabled = True
   Txt_Search_CPF.enabled = True
   Txt_Search_Name.enabled = True
   Opt_Sort_Code.enabled = True
   Opt_Sort_Name.enabled = True
   Grid_Customer.enabled = True
End Sub

Private Sub Form_Terminate()

W_DB.Close
Tabela_Clientes.Close

End Sub

Private Sub Grid_Customer_Click()
    With Grid_Customer
        If .RowSel = 1 Then
            Exit Sub
        End If
        Call Show_Record(Return_Recordset(Return_SqlString(2, .TextMatrix(.RowSel, 0))))
    End With
    Enable_Atend_Button (Text_Cod.Text)
End Sub

Public Sub Refresh_Record_Shown()
    Call Grid_Customer_Click
End Sub

Private Sub Enable_Atend_Button(code As String)
    Dim count As Integer
    Dim rs As ADODB.Recordset
    
    Set rs = Return_Recordset(Return_SqlString(5, code))
    count = rs.RecordCount
    Cmd_Finaliza.enabled = count > 0
    rs.Close
    Set rs = Nothing
End Sub

Private Sub Grid_Customer_SelChange()
    Call Grid_Customer_Click
End Sub

Private Sub Opt_Sort_Code_Click()
    With Grid_Customer
        Call Fill_Grid(Return_Recordset(Return_SqlString(3, Txt_Search_Code.Text, Txt_Search_CPF.Text, Txt_Search_Name.Text)))
    End With
End Sub

Private Sub Opt_Sort_Name_Click()
    With Grid_Customer
        Call Fill_Grid(Return_Recordset(Return_SqlString(3, Txt_Search_Code.Text, Txt_Search_CPF.Text, Txt_Search_Name.Text)))
    End With
End Sub

Private Sub Text_Bairro_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_Celular_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_Cep_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_Cidade_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_Cnpj_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   If CGCValido(Text_Cnpj.Text) = False Then
      MsgBox ("CNPJ Invalido!!!")
      Text_Cnpj.Text = ""
   Else
      SendKeys "{TAB}"
   End If
End If

End Sub

Private Sub Text_Cpf_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   If CPFValido(Text_Cpf.Text) = False Then
      MsgBox ("CPF Invalido!!!")
      Text_Cpf.Text = ""
   Else
      SendKeys "{TAB}"
   End If
End If

End Sub

Private Sub Text_E_Mail_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_End_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_Fone_Com_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_Fone_Resid_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_NomeCli_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Private Sub Text_Uf_KeyPress(KeyAscii As Integer)

If KeyAscii = 13 Then
   SendKeys "{TAB}"
End If

End Sub

Sub Cad_Ed()

Combo_Uf.Clear
'Combo_Uf.AddItem "AC"
'Combo_Uf.AddItem "AL"
'Combo_Uf.AddItem "AM"
'Combo_Uf.AddItem "AP"
'Combo_Uf.AddItem "BA"
'Combo_Uf.AddItem "CE"
'Combo_Uf.AddItem "DF"
'Combo_Uf.AddItem "ES"
'Combo_Uf.AddItem "GO"
'Combo_Uf.AddItem "MA"
'Combo_Uf.AddItem "MG"
'Combo_Uf.AddItem "MS"
'Combo_Uf.AddItem "MT"
'Combo_Uf.AddItem "PA"
'Combo_Uf.AddItem "PB"
'Combo_Uf.AddItem "PE"
'Combo_Uf.AddItem "PI"
'Combo_Uf.AddItem "PR"
'Combo_Uf.AddItem "RJ"
'Combo_Uf.AddItem "RN"
'Combo_Uf.AddItem "RS"
'Combo_Uf.AddItem "RO"
'Combo_Uf.AddItem "RR"
'Combo_Uf.AddItem "SC"
'Combo_Uf.AddItem "SE"
Combo_Uf.AddItem "SP"
'Combo_Uf.AddItem "TO"
Combo_Uf.Text = "SP"


Combo_Zona.Clear
Combo_Zona.AddItem "INTERIOR"
Combo_Zona.AddItem "LITORAL"
Combo_Zona.AddItem "ABC"
Combo_Zona.AddItem "ZONA NORTE"
Combo_Zona.AddItem "ZONA LESTE"
Combo_Zona.AddItem "ZONA SUL"
Combo_Zona.AddItem "ZONA OESTE"

Call Lista_Empresa

Text_NomeCli.TabIndex = 1
Text_NomeCli.BackColor = vbYellow

Text_End.TabIndex = 3
Text_End.BackColor = vbYellow

Text_Bairro.TabIndex = 4
Text_Bairro.BackColor = vbYellow

Text_Cidade.TabIndex = 5
Text_Cidade.BackColor = vbYellow

Combo_Uf.TabIndex = 6
Combo_Uf.BackColor = vbYellow

Combo_Zona.TabIndex = 9
Combo_Zona.BackColor = vbYellow

Text_Fone_Resid.TabIndex = 10
Text_Fone_Resid.BackColor = vbYellow

Text_Fone_Com.TabIndex = 11
Text_Fone_Com.BackColor = vbYellow

Text_Celular.TabIndex = 12
Text_Celular.BackColor = vbYellow

Combo_Solicitante.TabIndex = 13
Combo_Solicitante.BackColor = vbYellow

Text_Contrato.TabIndex = 14
Text_Dt_Contrato.TabIndex = 15

Cmd_Salva.TabIndex = 16

End Sub
Sub Cad_Ed_Fim()

   Text_NomeCli.BackColor = vbWhite
   Text_End.BackColor = vbWhite
   Text_Bairro.BackColor = vbWhite
   Text_Cidade.BackColor = vbWhite
   Combo_Uf.BackColor = vbWhite
   Combo_Zona.BackColor = vbWhite
   Text_Fone_Resid.BackColor = vbWhite
   Text_Fone_Com.BackColor = vbWhite
   Text_Celular.BackColor = vbWhite
   Combo_Solicitante.BackColor = vbWhite

End Sub

Sub Lista_Empresa()

If Tabela_Empresas.BOF = True And Tabela_Empresas.EOF = True Then
Else
    Tabela_Empresas.MoveFirst
    Combo_Solicitante.Clear
    Do While Not Tabela_Empresas.EOF
       DoEvents
       Combo_Solicitante.AddItem Tabela_Empresas.Fields("Tipo_Cliente")
       Tabela_Empresas.MoveNext
    Loop
End If

End Sub

Private Sub Txt_Search_Code_KeyPress(KeyAscii As Integer)
    If KeyAscii <> 8 And KeyAscii <> 13 And Not IsNumeric(Chr(KeyAscii)) Then
        KeyAscii = 0
        'Txt_Search_Code.Text = ""
        Exit Sub
    End If
    If KeyAscii = 13 Then
        With Grid_Customer
            Call Fill_Grid(Return_Recordset(Return_SqlString(3, Txt_Search_Code.Text, Txt_Search_CPF.Text, Txt_Search_Name.Text)))
        End With
    End If
End Sub

Private Sub Txt_Search_CPF_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then
        With Grid_Customer
            Call Fill_Grid(Return_Recordset(Return_SqlString(3, Txt_Search_Code.Text, Txt_Search_CPF.Text, Txt_Search_Name.Text)))
        End With
    End If
End Sub

Private Sub Txt_Search_Name_KeyPress(KeyAscii As Integer)
    If KeyAscii = 13 Then
        With Grid_Customer
            Call Fill_Grid(Return_Recordset(Return_SqlString(3, Txt_Search_Code.Text, Txt_Search_CPF.Text, Txt_Search_Name.Text)))
        End With
    End If
End Sub

