VERSION 5.00
Object = "{5E9E78A0-531B-11CF-91F6-C2863C385E30}#1.0#0"; "MSFLXGRD.OCX"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Begin VB.Form Form_Visit_Manager 
   Caption         =   "Gerenciador de Visitas"
   ClientHeight    =   8985
   ClientLeft      =   120
   ClientTop       =   450
   ClientWidth     =   16830
   LinkTopic       =   "Form1"
   ScaleHeight     =   8985
   ScaleWidth      =   16830
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame4 
      Caption         =   "Controles"
      Height          =   975
      Left            =   9480
      TabIndex        =   18
      Top             =   7560
      Width           =   7215
      Begin VB.CommandButton But_Close 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   6480
         Picture         =   "Form_Visit_Manager.frx":0000
         Style           =   1  'Graphical
         TabIndex        =   23
         Top             =   240
         UseMaskColor    =   -1  'True
         Width           =   525
      End
      Begin VB.CommandButton But_Alterar 
         Caption         =   "&Alterar"
         Height          =   495
         Left            =   1440
         TabIndex        =   22
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton But_Salvar 
         Caption         =   "&Salvar"
         Height          =   495
         Left            =   2760
         TabIndex        =   21
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton But_Incluir 
         BackColor       =   &H0080FF80&
         Caption         =   "&Incluir"
         Height          =   495
         Left            =   120
         Style           =   1  'Graphical
         TabIndex        =   20
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton But_Excluir 
         BackColor       =   &H008080FF&
         Caption         =   "E&xcluir"
         Height          =   495
         Left            =   4080
         Style           =   1  'Graphical
         TabIndex        =   19
         Top             =   240
         Width           =   1215
      End
   End
   Begin VB.Frame Frame3 
      Caption         =   "Hist�rico de Modifica��es"
      Height          =   5175
      Left            =   9480
      TabIndex        =   2
      Top             =   2400
      Width           =   7215
      Begin MSFlexGridLib.MSFlexGrid Grid_Hist 
         Height          =   4815
         Left            =   120
         TabIndex        =   17
         Top             =   240
         Width           =   6975
         _ExtentX        =   12303
         _ExtentY        =   8493
         _Version        =   393216
         Rows            =   1
         Cols            =   5
         FixedRows       =   0
         FixedCols       =   0
         ScrollBars      =   2
         SelectionMode   =   1
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Pr�ximas Visitas"
      Height          =   6135
      Left            =   120
      TabIndex        =   1
      Top             =   2400
      Width           =   9255
      Begin MSFlexGridLib.MSFlexGrid Grid_Prox_Visita 
         Height          =   5775
         Left            =   120
         TabIndex        =   16
         Top             =   240
         Width           =   9015
         _ExtentX        =   15901
         _ExtentY        =   10186
         _Version        =   393216
         Rows            =   1
         Cols            =   5
         FixedRows       =   0
         FixedCols       =   0
         ScrollBars      =   2
         SelectionMode   =   1
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Dados"
      Height          =   2295
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   16575
      Begin VB.TextBox Txt_Obs 
         BackColor       =   &H8000000F&
         Height          =   1695
         Left            =   9360
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   14
         Top             =   360
         Width           =   7095
      End
      Begin VB.TextBox Txt_Dt_Expiracao 
         BackColor       =   &H8000000F&
         Enabled         =   0   'False
         Height          =   285
         Left            =   1920
         TabIndex        =   12
         Top             =   1800
         Width           =   2415
      End
      Begin VB.TextBox Txt_Dt_Criacao 
         BackColor       =   &H8000000F&
         Enabled         =   0   'False
         Height          =   285
         Left            =   1920
         TabIndex        =   9
         Top             =   1440
         Width           =   2415
      End
      Begin VB.TextBox Txt_Nome_Cliente 
         BackColor       =   &H8000000F&
         Enabled         =   0   'False
         Height          =   285
         Left            =   3240
         TabIndex        =   7
         Top             =   720
         Width           =   4335
      End
      Begin VB.TextBox Txt_Cod_Cliente 
         BackColor       =   &H8000000F&
         Enabled         =   0   'False
         Height          =   285
         Left            =   1920
         TabIndex        =   6
         Top             =   720
         Width           =   1215
      End
      Begin VB.TextBox Txt_Cod_Visita 
         BackColor       =   &H8000000F&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   1920
         TabIndex        =   3
         Top             =   360
         Width           =   1215
      End
      Begin MSMask.MaskEdBox Mask_Dt_Prox_Visita 
         BeginProperty DataFormat 
            Type            =   1
            Format          =   "dd/MM/yyyy"
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1046
            SubFormatType   =   3
         EndProperty
         Height          =   285
         Left            =   1920
         TabIndex        =   15
         Top             =   1080
         Width           =   1215
         _ExtentX        =   2143
         _ExtentY        =   503
         _Version        =   393216
         BackColor       =   -2147483633
         Enabled         =   0   'False
         MaxLength       =   10
         Format          =   "dd/mm/yyyy"
         Mask            =   "##/##/####"
         PromptChar      =   "_"
      End
      Begin VB.Label Label1 
         Alignment       =   1  'Right Justify
         Caption         =   "Observa��o.:"
         Height          =   255
         Left            =   8280
         TabIndex        =   13
         Top             =   360
         Width           =   975
      End
      Begin VB.Label Lbl_Dt_Expiracao 
         Alignment       =   1  'Right Justify
         Caption         =   "Data de Expira��o:"
         Height          =   255
         Left            =   360
         TabIndex        =   11
         Top             =   1800
         Width           =   1455
      End
      Begin VB.Label Lbl_Dt_Prox_Visita 
         Alignment       =   1  'Right Justify
         Caption         =   "Data da Pr�xima Visita:"
         Height          =   255
         Left            =   120
         TabIndex        =   10
         Top             =   1080
         Width           =   1695
      End
      Begin VB.Label Lbl_Dt_Criacao 
         Alignment       =   1  'Right Justify
         Caption         =   "Data de Cria��o:"
         Height          =   255
         Left            =   480
         TabIndex        =   8
         Top             =   1440
         Width           =   1335
      End
      Begin VB.Label Lbl_Cliente 
         Alignment       =   1  'Right Justify
         Caption         =   "Cliente:"
         Height          =   255
         Left            =   480
         TabIndex        =   5
         Top             =   720
         Width           =   1335
      End
      Begin VB.Label Lbl_Cod_Visita 
         Alignment       =   1  'Right Justify
         Caption         =   "C�digo da Visita:"
         Height          =   255
         Left            =   600
         TabIndex        =   4
         Top             =   360
         Width           =   1215
      End
   End
End
Attribute VB_Name = "Form_Visit_Manager"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Declare Function GetSysColor Lib "user32" (ByVal nIndex As Long) As Long
Const COLOR_BTNFACE = 15 'Button

Public W_DB As ADODB.Connection

Private Sub But_Alterar_Click()
    Txt_Obs.Locked = But_Alterar.Caption <> "&Alterar"
    Txt_Obs.BackColor = IIf(Not Txt_Obs.Locked, RGB(255, 255, 255), GetSysColor(COLOR_BTNFACE))
    But_Alterar.Caption = IIf(Not Txt_Obs.Locked, "&Cancelar", "&Alterar")
    If Not Txt_Obs.Locked Then
        Call Clean_TextBox
    Else
        Call Grid_Hist_Click
    End If
    Call Configure_Controls(IIf(Not Txt_Obs.Locked, 2, 0))
End Sub

Private Sub But_Close_Click()
    Unload Me
End Sub

Private Sub But_Excluir_Click()
    If MsgBox("Confirma a Exclus�o da Visita ao Cliente " & Txt_Nome_Cliente.Text & " ? ", vbYesNo, "Excluir Visita") = vbYes Then
        Call Expire_Visit(, Txt_Cod_Visita.Text)
        Call Fill_Grid(Return_Recordset(Return_SqlString(1)), Txt_Cod_Cliente.Text)
    End If
End Sub

Private Sub But_Incluir_Click()
    Mask_Dt_Prox_Visita.enabled = But_Incluir.Caption = "&Incluir"
    Txt_Obs.Locked = Not Mask_Dt_Prox_Visita.enabled
    Mask_Dt_Prox_Visita.BackColor = IIf(Not Txt_Obs.Locked, RGB(255, 255, 255), GetSysColor(COLOR_BTNFACE))
    Txt_Obs.BackColor = Mask_Dt_Prox_Visita.BackColor
    But_Incluir.Caption = IIf(Not Txt_Obs.Locked, "&Cancelar", "&Incluir")
    If Not Txt_Obs.Locked Then
        Call Clean_TextBox
    Else
        Call Grid_Hist_Click
    End If
    Call Configure_Controls(IIf(Not Txt_Obs.Locked, 1, 0))
End Sub

Private Sub Clean_TextBox()
    If Mask_Dt_Prox_Visita.enabled Then
        Txt_Cod_Visita.Text = ""
        Mask_Dt_Prox_Visita.Text = "__/__/____"
        Txt_Dt_Criacao.Text = ""
        Txt_Dt_Expiracao.Text = ""
        Txt_Obs.Text = ""
    End If
End Sub

Private Sub But_Salvar_Click()
    Dim Insert As Boolean
    
    Insert = False
    If Mask_Dt_Prox_Visita.enabled Then
        Insert = True
        If Not Validate_Fields() Then
            Exit Sub
        End If
        Mask_Dt_Prox_Visita.enabled = False
        Mask_Dt_Prox_Visita.BackColor = GetSysColor(COLOR_BTNFACE)
    End If
    Txt_Obs.Locked = True
    Txt_Obs.BackColor = GetSysColor(COLOR_BTNFACE)
    But_Incluir.Caption = "&Incluir"
    But_Alterar.Caption = "&Alterar"
    If Insert Then
        Call Insert_New_Visit(Txt_Cod_Cliente.Text)
    Else
        Call Update_Visit(Txt_Cod_Visita.Text)
    End If
    
    Call Fill_Grid(Return_Recordset(Return_SqlString(1)), Txt_Cod_Cliente.Text)
    'Call Grid_Prox_Visita_Click
    Call Configure_Controls(IIf(Not Txt_Obs.Locked, 1, 0))
End Sub

Private Sub Insert_New_Visit(clientCode As String)
    Dim rs As ADODB.Recordset
    
    Set rs = Return_Recordset(Return_SqlString(2, clientCode))
    Call Expire_Visit(clientCode)
    rs.AddNew
    
    rs.Fields("Cod_Cliente") = clientCode
    rs.Fields("Dt_Criacao") = Now
    rs.Fields("Dt_Prox_Visita") = Mask_Dt_Prox_Visita.Text
    rs.Fields("Obs") = Txt_Obs.Text
    
    rs.Update
    
    rs.Close
    Set rs = Nothing
End Sub

Private Sub Update_Visit(code As String)
    Dim rs As ADODB.Recordset
    
    Set rs = Return_Recordset(Return_SqlString(3, code))
    rs.Fields("Obs") = Txt_Obs.Text
    
    rs.Update
    
    rs.Close
    Set rs = Nothing
End Sub

Private Sub Expire_Visit(Optional clientCode As String, Optional code As String)
    If clientCode <> "" Then
        W_DB.Execute "UPDATE Visitas SET Dt_Expiracao = Now() WHERE Dt_Expiracao IS NULL AND cod_cliente = " + clientCode
    Else
        W_DB.Execute "UPDATE Visitas SET Dt_Expiracao = Now() WHERE codigo = " + code
    End If
End Sub

Private Function Validate_Fields() As Boolean
    Dim dias As Integer
    
    Validate_Fields = False
    
    dias = DateDiff("d", Date, vData(Mask_Dt_Prox_Visita))
    If dias < 0 Then
        MsgBox "A data deve ser maior que o dia de hoje!", vbOKOnly, "X.Sol Arte em Aquecedores"
        Mask_Dt_Prox_Visita.SetFocus
        Exit Function
    End If
    If Trim(Mask_Dt_Prox_Visita.Text) = "__/__/____" Or Not IsDate(Mask_Dt_Prox_Visita.Text) Then
      MsgBox "� necess�rio digitar uma data v�lida!", vbOKOnly, "X.Sol Arte em Aquecedores"
      Mask_Dt_Prox_Visita.SetFocus
      Exit Function
    End If
    
    Validate_Fields = True
End Function

Private Sub Form_Load()
    Dim hMenu As Long
    Dim lItemCount As Long
    
    hMenu = GetSystemMenu(Me.hWnd, 0)
    If hMenu Then
       lItemCount = GetMenuItemCount(hMenu)
       Call RemoveMenu(hMenu, lItemCount - 1, MF_REMOVE Or _
       MF_BYPOSITION)
        Call RemoveMenu(hMenu, lItemCount - 2, MF_REMOVE Or _
        MF_BYPOSITION)
       Call DrawMenuBar(Me.hWnd)
    End If

    Set W_DB = New ADODB.Connection
    W_DB.Open "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" & W_DBname & ";"

    Call Configure_Grid
    Call Fill_Grid(Return_Recordset(Return_SqlString(1)))
End Sub

Private Sub Configure_Controls(Optional status As Integer)
    Dim enabled As Boolean
    
    enabled = False
    But_Incluir.enabled = Grid_Prox_Visita.RowSel > 0 And status <= 1
    If status = 0 Then
        With Grid_Hist
            If .RowSel > 0 Then
                enabled = Grid_Hist.TextMatrix(.RowSel, 3) = ""
            End If
        End With
    End If
    But_Alterar.enabled = enabled Or status = 2
    But_Salvar.enabled = Not Txt_Obs.Locked
    But_Excluir.enabled = enabled
    But_Close.enabled = status = 0
    Grid_Prox_Visita.enabled = status = 0
    Grid_Hist.enabled = status = 0
End Sub


Private Function GET_BACKCOLOR(d As Date) As Long
    If (d < Date) Then
        GET_BACKCOLOR = RGB(250, 160, 160)
    ElseIf d = Date Then
        GET_BACKCOLOR = RGB(255, 255, 71)
    ElseIf d < DateAdd("d", 7, Date) Then
        GET_BACKCOLOR = RGB(250, 192, 144)
    ElseIf d < DateAdd("m", 1, Date) Then
        GET_BACKCOLOR = RGB(0, 255, 0)
    Else
        GET_BACKCOLOR = 0
    End If
End Function

Private Sub Fill_Grid(rs As ADODB.Recordset, Optional code As String)
    Dim count As Integer
    Dim col As Integer
    Dim selectedRow As Integer
    Dim bkColor As Long
    
    count = 2
    selectedRow = 2
    With Grid_Prox_Visita
        .Rows = 2
        Do Until rs.EOF
            .AddItem (rs.Fields("v.codigo") & vbTab & rs.Fields("Cod_Cliente") & vbTab & IIf(IsNull(rs.Fields("Nome_Cli")), "", rs.Fields("Nome_Cli")) & vbTab + CStr(rs.Fields("Dt_Prox_Visita")))
            bkColor = GET_BACKCOLOR(rs.Fields("Dt_Prox_Visita"))
            If bkColor <> 0 Then
                .Row = .Rows - 1
                For col = .FixedCols To .Cols - 1
                    .col = col
                    .CellBackColor = bkColor
                Next
            End If
            If code <> "" Then
                If code = rs.Fields("Cod_Cliente") Then
                    selectedRow = count
                End If
                count = count + 1
            End If
            rs.MoveNext
        Loop
        
        .Refresh
        If rs.RecordCount > 0 Then
            .Row = selectedRow
            .RowSel = selectedRow
            .TopRow = selectedRow
            .col = 0
            .ColSel = .Cols - 1
            Call Grid_Prox_Visita_Click
'            Cmd_Edita.Enabled = True
'            Cmd_Exclui.Enabled = True
'        Else
'            Cmd_Edita.Enabled = False
'            Cmd_Exclui.Enabled = False
'            Cmd_Atende.Enabled = False
'            Cmd_Finaliza.Enabled = False
'            Call LimpaControles
        End If
    End With
    
    rs.Close
    Set rs = Nothing
End Sub

Private Sub Fill_Grid_Hist(rs As ADODB.Recordset, Optional code As String)
    Dim col As Integer
    Dim selectedRow As Integer
    Dim bkColor As Long
    Dim dtExp As String
    
    selectedRow = 0
    With Grid_Hist
        .Rows = 2
        Do Until rs.EOF
            If IsNull(rs.Fields("Dt_Expiracao")) Then
                dtExp = ""
            Else
                dtExp = CStr(rs.Fields("Dt_Expiracao"))
            End If
            
            .AddItem (rs.Fields("Codigo") & vbTab & IIf(IsNull(rs.Fields("Dt_Prox_Visita")), "", rs.Fields("Dt_Prox_Visita")) & vbTab & rs.Fields("Dt_Criacao") & vbTab & dtExp)
            If IsNull(rs.Fields("Dt_Expiracao")) Then
                .Row = .Rows - 1
                bkColor = RGB(0, 255, 0)
                For col = .FixedCols To .Cols - 1
                    .col = col
                    .CellBackColor = bkColor
                Next
            End If
            If code <> "" Then
                If code = rs.Fields("codigo") Then
                    selectedRow = .Rows - 1
                End If
            End If
            rs.MoveNext
        Loop
        If selectedRow = 0 Then
           selectedRow = .Rows - 1
        End If
        
        .Refresh
        If rs.RecordCount > 0 Then
            .Row = selectedRow
            .RowSel = selectedRow
            .TopRow = selectedRow
            .col = 0
            .ColSel = .Cols - 1
            Call Grid_Hist_Click
'            Cmd_Edita.Enabled = True
'            Cmd_Exclui.Enabled = True
'        Else
'            Cmd_Edita.Enabled = False
'            Cmd_Exclui.Enabled = False
'            Cmd_Atende.Enabled = False
'            Cmd_Finaliza.Enabled = False
'            Call LimpaControles
        End If
    End With
    
    rs.Close
    Set rs = Nothing
End Sub
Private Sub Configure_Grid()
    With Grid_Prox_Visita
        .Cols = 4
        .FixedCols = 0
        .ColWidth(0) = 750
        .ColWidth(1) = 1000
        .ColWidth(2) = 5700
        .ColWidth(3) = 1200
        .ColAlignment(0) = flexAlignCenterCenter
        .ColAlignment(1) = flexAlignCenterCenter
        .ColAlignment(2) = flexAlignLeftCenter
        .ColAlignment(3) = flexAlignCenterCenter
        .SelectionMode = flexSelectionByRow
        .HighLight = flexHighlightAlways
        .Rows = 2
        .FixedRows = 1
        .TextMatrix(0, 0) = "C�digo"
        .TextMatrix(0, 1) = "C�d Cliente"
        .TextMatrix(0, 2) = "Nome"
        .TextMatrix(0, 3) = "Pr�x Visita"
        .RowHeight(1) = 0
    End With
    With Grid_Hist
        .Cols = 4
        .FixedCols = 0
        .ColWidth(0) = 800
        .ColWidth(1) = 1850
        .ColWidth(2) = 2000
        .ColWidth(3) = 2000
        .ColAlignment(0) = flexAlignCenterCenter
        .ColAlignment(1) = flexAlignCenterCenter
        .ColAlignment(2) = flexAlignCenterCenter
        .ColAlignment(3) = flexAlignCenterCenter
        .SelectionMode = flexSelectionByRow
        .HighLight = flexHighlightAlways
        .Rows = 2
        .FixedRows = 1
        .TextMatrix(0, 0) = "C�digo"
        .TextMatrix(0, 1) = "Visita"
        .TextMatrix(0, 2) = "Dt Cria��o"
        .TextMatrix(0, 3) = "Dt Expira��o"
        .RowHeight(1) = 0
    End With
End Sub

Private Function Return_SqlString(queryType As Integer, Optional param1 As String) As String
    Dim whereClause As String
    
    If queryType = 1 Then
        Return_SqlString = "SELECT * FROM Visitas v, Clientes c WHERE v.cod_cliente = c.codigo AND Dt_Expiracao IS NULL ORDER BY Dt_Prox_Visita"
    ElseIf queryType = 2 Then
        Return_SqlString = "SELECT * FROM Visitas WHERE Cod_Cliente = " & param1 & " ORDER BY Codigo"
    ElseIf queryType = 3 Then
        Return_SqlString = "SELECT * FROM Visitas WHERE Codigo = " & param1
    End If
End Function

Private Function Return_Recordset(strSql As String) As ADODB.Recordset
    Dim rs As New ADODB.Recordset
    
    rs.Open strSql, W_DB, adOpenStatic, adLockOptimistic
    
    Set Return_Recordset = rs
End Function

Private Sub Grid_Hist_Click()
    With Grid_Hist
        If .RowSel = 1 Then
            Exit Sub
        End If
        Call Show_Visit_Detail(Return_Recordset(Return_SqlString(3, .TextMatrix(.RowSel, 0))))
    End With
    Call Configure_Controls
End Sub

Private Sub Show_Visit_Detail(rs As ADODB.Recordset)
    Txt_Cod_Visita.Text = rs.Fields("Codigo")
    Mask_Dt_Prox_Visita.Text = rs.Fields("Dt_Prox_Visita")
    Txt_Dt_Criacao.Text = rs.Fields("Dt_Criacao")
    Txt_Dt_Expiracao.Text = IIf(IsNull(rs.Fields("Dt_Expiracao")), "", rs.Fields("Dt_Expiracao"))
    Txt_Obs.Text = IIf(IsNull(rs.Fields("Obs")), "", rs.Fields("Obs"))
    rs.Close
    Set rs = Nothing
End Sub

Private Sub Grid_Hist_SelChange()
    Call Grid_Hist_Click
End Sub

Private Sub Grid_Prox_Visita_Click()
    With Grid_Prox_Visita
        If .RowSel = 1 Then
            Exit Sub
        End If
        Call Show_Visit_Hist
    End With
End Sub

Private Sub Show_Visit_Hist()
    With Grid_Prox_Visita
        Txt_Cod_Cliente = .TextMatrix(.RowSel, 1)
        Txt_Nome_Cliente = .TextMatrix(.RowSel, 2)
        Call Fill_Grid_Hist(Return_Recordset(Return_SqlString(2, .TextMatrix(.RowSel, 1))))
    End With
End Sub

Private Sub Grid_Prox_Visita_SelChange()
    Call Grid_Prox_Visita_Click
End Sub
