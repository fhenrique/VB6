VERSION 5.00
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Begin VB.Form Form_Xsol_05 
   Caption         =   "Atendimento Xsol Arte em Aquecedores"
   ClientHeight    =   6045
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7725
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6045
   ScaleWidth      =   7725
   StartUpPosition =   3  'Windows Default
   Begin MSMask.MaskEdBox Mask_Dt_Serv 
      BeginProperty DataFormat 
         Type            =   1
         Format          =   "dd/MM/yyyy"
         HaveTrueFalseNull=   0
         FirstDayOfWeek  =   0
         FirstWeekOfYear =   0
         LCID            =   1046
         SubFormatType   =   3
      EndProperty
      Height          =   285
      Left            =   2640
      TabIndex        =   34
      Top             =   2000
      Width           =   1215
      _ExtentX        =   2143
      _ExtentY        =   503
      _Version        =   393216
      MaxLength       =   10
      Format          =   "dd/mm/yyyy"
      Mask            =   "##/##/####"
      PromptChar      =   "_"
   End
   Begin VB.TextBox Text_OS 
      BackColor       =   &H80000004&
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H8000000C&
      Height          =   350
      Left            =   2640
      TabIndex        =   33
      Text            =   "Text1"
      Top             =   240
      Width           =   1455
   End
   Begin VB.ComboBox Combo_Ficha 
      Height          =   315
      Left            =   2640
      Style           =   2  'Dropdown List
      TabIndex        =   31
      Top             =   2400
      Width           =   1935
   End
   Begin VB.ComboBox Combo_Tecnico 
      Height          =   315
      Left            =   2640
      Style           =   2  'Dropdown List
      TabIndex        =   30
      Top             =   840
      Width           =   4815
   End
   Begin VB.TextBox Text_Tecnico 
      Height          =   285
      Left            =   3120
      TabIndex        =   29
      Top             =   840
      Width           =   4095
   End
   Begin VB.TextBox Text_Status 
      Alignment       =   2  'Center
      Enabled         =   0   'False
      Height          =   285
      Left            =   2640
      TabIndex        =   28
      Top             =   3120
      Width           =   1575
   End
   Begin VB.Frame Frame2 
      Caption         =   "Controle"
      Height          =   1575
      Left            =   120
      TabIndex        =   17
      Top             =   4320
      Width           =   7455
      Begin VB.CommandButton Cmd_Edita 
         Caption         =   "&Editar"
         Height          =   495
         Left            =   4080
         TabIndex        =   25
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Exclui 
         Caption         =   "E&xclui"
         Height          =   495
         Left            =   6120
         TabIndex        =   24
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Salva 
         Caption         =   "&Salvar"
         Height          =   495
         Left            =   2040
         TabIndex        =   23
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Inclui 
         Caption         =   "&Incluir"
         Height          =   495
         Left            =   120
         TabIndex        =   22
         Top             =   240
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Ultimo 
         Caption         =   "&�ltimo  >>"
         Height          =   495
         Left            =   6120
         TabIndex        =   21
         Top             =   840
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Proximo 
         Caption         =   "Pr&oximo  >"
         Height          =   495
         Left            =   4080
         TabIndex        =   20
         Top             =   840
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Anterior 
         Caption         =   "<  &Anterior"
         Height          =   495
         Left            =   2040
         TabIndex        =   19
         Top             =   840
         Width           =   1215
      End
      Begin VB.CommandButton Cmd_Primeiro 
         Caption         =   "<<   &Primeiro"
         Height          =   495
         Left            =   120
         TabIndex        =   18
         Top             =   840
         Width           =   1215
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Fichas"
      Height          =   2175
      Left            =   5040
      TabIndex        =   13
      Top             =   2040
      Width           =   2535
      Begin VB.CommandButton Cmd_Print 
         Caption         =   "&Imprimir"
         Height          =   495
         Left            =   720
         TabIndex        =   26
         Top             =   1440
         Width           =   1215
      End
      Begin VB.OptionButton Option_Assistencia 
         Caption         =   "Assist�ncia T�cnica"
         Height          =   195
         Left            =   120
         TabIndex        =   16
         Top             =   1000
         Width           =   2055
      End
      Begin VB.OptionButton Option_Inst_Pisc 
         Caption         =   "Instala��o de Piscina"
         Height          =   195
         Left            =   120
         TabIndex        =   15
         Top             =   660
         Width           =   2175
      End
      Begin VB.OptionButton Option_Inst_Res 
         Caption         =   "Instala��o de Resid�ncia"
         Height          =   255
         Left            =   120
         TabIndex        =   14
         Top             =   300
         Width           =   2295
      End
   End
   Begin VB.TextBox Text_NomeCli 
      Height          =   285
      Left            =   2640
      TabIndex        =   11
      Top             =   1200
      Width           =   4575
   End
   Begin VB.ComboBox Combo_Servico 
      Height          =   315
      Left            =   2640
      Style           =   2  'Dropdown List
      TabIndex        =   9
      Top             =   1560
      Width           =   3375
   End
   Begin VB.TextBox Text_Ficha 
      Height          =   285
      Left            =   2640
      TabIndex        =   6
      Top             =   2400
      Width           =   1575
   End
   Begin VB.TextBox Text_Serv_Solic 
      Height          =   285
      Left            =   2640
      TabIndex        =   5
      Top             =   1560
      Width           =   3375
   End
   Begin VB.TextBox Text_Valor 
      Height          =   285
      Left            =   2640
      TabIndex        =   4
      Top             =   2760
      Width           =   1095
   End
   Begin VB.CommandButton Cmd_Fechar 
      Caption         =   "Fechar"
      Height          =   495
      Left            =   3240
      TabIndex        =   2
      Top             =   3600
      Width           =   1215
   End
   Begin VB.TextBox Text_Tecnico_Cod 
      Alignment       =   2  'Center
      Height          =   285
      Left            =   2640
      TabIndex        =   1
      Top             =   840
      Width           =   375
   End
   Begin VB.Label Lbl_OS 
      Alignment       =   1  'Right Justify
      Caption         =   "OS:"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1800
      TabIndex        =   32
      Top             =   290
      Width           =   615
   End
   Begin VB.Label LblStatus 
      Alignment       =   1  'Right Justify
      Caption         =   "Posi��o Ficha:"
      Height          =   255
      Left            =   1440
      TabIndex        =   27
      Top             =   3120
      Width           =   1095
   End
   Begin VB.Image Image1 
      Height          =   1245
      Left            =   7080
      Picture         =   "Form_Xsol_05.frx":0000
      Top             =   1200
      Visible         =   0   'False
      Width           =   2820
   End
   Begin VB.Label Lbl_Nome 
      Alignment       =   1  'Right Justify
      Caption         =   "Nome do Cliente / Raz�o Social:"
      Height          =   255
      Left            =   120
      TabIndex        =   12
      Top             =   1200
      Width           =   2415
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Caption         =   "Data Serv.:"
      Height          =   255
      Left            =   1560
      TabIndex        =   10
      Top             =   2040
      Width           =   855
   End
   Begin VB.Label Lbl_Ficha 
      Alignment       =   1  'Right Justify
      Caption         =   "Ficha de Atendimento:"
      Height          =   255
      Left            =   840
      TabIndex        =   8
      Top             =   2400
      Width           =   1695
   End
   Begin VB.Label Lbl_Serv_Solic 
      Alignment       =   1  'Right Justify
      Caption         =   "Servi�o Solicitado:"
      Height          =   255
      Left            =   1080
      TabIndex        =   7
      Top             =   1560
      Width           =   1335
   End
   Begin VB.Label Lbl_Valor 
      Alignment       =   1  'Right Justify
      Caption         =   "Valor:"
      Height          =   255
      Left            =   2040
      TabIndex        =   3
      Top             =   2760
      Width           =   495
   End
   Begin VB.Label Lbl_Tec 
      Alignment       =   1  'Right Justify
      Caption         =   "T�cnico:"
      Height          =   255
      Left            =   1800
      TabIndex        =   0
      Top             =   840
      Width           =   615
   End
End
Attribute VB_Name = "Form_Xsol_05"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public W_DB As Connection
Public Tabela_Tecnicos As Recordset
Public Tabela_Servicos As Recordset
Public Tabela_Atendimento As Recordset
Public Tabela_Clientes As Recordset
Public Tabela_Visitas As Recordset

Private Sub Cmd_Anterior_Click()

If Tabela_Atendimento.BOF = False Then
   Tabela_Atendimento.MovePrevious
   Call Mostra_Registro
   If Tabela_Atendimento.BOF = True Then
      Tabela_Atendimento.MoveFirst
      Call Mostra_Registro
   End If
   Else
   If Tabela_Atendimento.EOF Then
      MsgBox "N�o h� dados no Arquivo!", , "Sem Dados !"
   Else
      Tabela_Atendimento.MoveFirst
      Call Mostra_Registro
   End If
End If

End Sub

Private Sub Cmd_Edita_Click()

    If Cmd_Edita.Caption = "&Editar" Then
            
        Cmd_Edita.Caption = "&Cancela"
    
        Cmd_Salva.enabled = True
        
        Call Lista_Servico
        Call Lista_Tecnico
        Call Lista_Ficha
        Call DesabilitaNavegacao
        
        Cmd_Inclui.enabled = False
        Cmd_Exclui.enabled = False
        
        Call Destrava_Registro
               
        
    ElseIf Cmd_Edita.Caption = "&Cancela" Then
        Cmd_Edita.Caption = "&Editar"
        
        Cmd_Salva.enabled = False
        
        Call HabilitaNavegacao
        
        Cmd_Inclui.enabled = True
        Cmd_Exclui.enabled = True
        
        
        Call Trava_Registro
                
        
    End If

 
End Sub

Private Sub Cmd_Exclui_Click()

If MsgBox("Confirma Exclus�o deste Registro ? ", vbYesNo, "Excluir Registros") = vbYes Then
        
   On Error Resume Next
        
   Tabela_Atendimento.Delete
        
   Tabela_Atendimento.MoveNext
   If Tabela_Atendimento.EOF = True Then
      Tabela_Atendimento.MoveLast
      If Tabela_Atendimento.BOF = True Then
         Call LimpaControles
              MsgBox "N�o h� dados no Arquivo!", , "Sem Dados !"
      End If
   End If
   ElseIf Tabela_Atendimento.EOF = True And Tabela_Atendimento.BOF = True Then
                MsgBox "N�o h� dados no Arquivo!", , "Sem Dados !"
End If
Call Mostra_Registro

End Sub

Private Sub Cmd_Fechar_Click()

Call Form_Xsol_02.Refresh_Record_Shown

Unload Me

End Sub

Private Sub Cmd_Inclui_Click()

If Cmd_Inclui.Caption = "&Incluir" Then
   Text_NomeCli.Text = Nome_Cli_Atend
   Cmd_Inclui.Caption = "&Cancela"
   Cmd_Salva.enabled = True
   Cmd_Edita.enabled = False
   Cmd_Exclui.enabled = False
   Cmd_Print.enabled = False
   
   Call DesabilitaNavegacao
   Call LimpaControles
   Call Destrava_Registro
   Call Lista_Tecnico
   Call Lista_Servico
   Call Lista_Ficha

   Combo_Tecnico.SetFocus
   
ElseIf Cmd_Inclui.Caption = "&Cancela" Then
   Text_NomeCli.Text = ""
   Cmd_Inclui.Caption = "&Incluir"
   Cmd_Salva.enabled = False
   Cmd_Edita.enabled = True
   Cmd_Exclui.enabled = True
   Cmd_Print.enabled = True
   
   Call Trava_Registro
   Call HabilitaNavegacao
   Call Mostra_Registro
   
   'Call Cad_Ed_Fim

End If

End Sub

Private Sub Cmd_Primeiro_Click()

If Tabela_Atendimento.BOF = False Then
   Tabela_Atendimento.MoveFirst
   Call Mostra_Registro
ElseIf Tabela_Atendimento.BOF = True _
   And Tabela_Atendimento.EOF = True Then
   MsgBox "N�o h� dados no Arquivo!", , "Sem Dados !"
End If

End Sub

Private Sub Cmd_Print_Click()

    If Option_Assistencia = True Then
       Call Ficha(3)
'       Option_Assistencia = False
'       Option_Inst_Pisc = False
'       Option_Inst_Res = False
    End If
    
    If Option_Inst_Pisc = True Then
       Call Ficha(2)
'       Option_Assistencia = False
'       Option_Inst_Pisc = False
'       Option_Inst_Res = False
    End If
    
    If Option_Inst_Res = True Then
       Call Ficha(1)
    End If

    Option_Assistencia = False
    Option_Inst_Pisc = False
    Option_Inst_Res = False
End Sub

Private Sub Cmd_Proximo_Click()

If Tabela_Atendimento.EOF = False Then
   Tabela_Atendimento.MoveNext
   Call Mostra_Registro
   If Tabela_Atendimento.EOF Then
      Tabela_Atendimento.MoveLast
      Call Mostra_Registro
   End If
Else
   If Tabela_Atendimento.BOF Then
      MsgBox "N�o h� dados no Arquivo!", , "Sem Dados !"
   Else
      Tabela_Atendimento.MoveLast
      Call Mostra_Registro
   End If
End If

End Sub

Private Sub Cmd_Salva_Click()

Dim dias As Integer

If Trim(Combo_Tecnico.Text) = "" Then
   MsgBox "� necess�rio selecionar o t�cnico!", vbOKOnly, "X.Sol Arte em Aquecedores"
   Combo_Tecnico.SetFocus
   Exit Sub
End If

If Trim(Combo_Servico.Text) = "" Then
   MsgBox "� necess�rio selecionar o Servi�o!", vbOKOnly, "X.Sol Arte em Aquecedores"
   Combo_Servico.SetFocus
   Exit Sub
End If

dias = DateDiff("d", Date, vData(Mask_Dt_Serv))
If dias < 0 Or Trim(Mask_Dt_Serv.Text) = "__/__/____" Or Not IsDate(Mask_Dt_Serv.Text) Then
  MsgBox "� necess�rio digitar um dia valido!", vbOKOnly, "X.Sol Arte em Aquecedores"
  Mask_Dt_Serv.SetFocus
  Exit Sub
End If

If Trim(Combo_Ficha.Text) = "" Then
   MsgBox "� necess�rio selecionar a Ficha!", vbOKOnly, "X.Sol Arte em Aquecedores"
   Combo_Ficha.SetFocus
   Exit Sub
End If


If Cmd_Inclui.Caption = "&Cancela" Then
   Tabela_Atendimento.AddNew
   
   If Generate_Next_Visit(Combo_Servico.Text) Then
      Tabela_Visitas.AddNew
   End If
End If

Call GravaRegistros

Tabela_Atendimento.Update

If Generate_Next_Visit(Combo_Servico.Text) Then
    Tabela_Visitas.Update
End If

Call Trava_Registro
Call HabilitaNavegacao
Call Mostra_Registro

If Cmd_Inclui.Caption = "&Cancela" Then
   Cmd_Inclui.Caption = "&Incluir"
End If
    
If Cmd_Edita.Caption = "&Cancela" Then
   Cmd_Edita.Caption = "&Editar"
End If
     
'Call Cad_Ed_Fim

Cmd_Edita.enabled = True
Cmd_Inclui.enabled = True
Cmd_Exclui.enabled = True
Cmd_Salva.enabled = False
Cmd_Print.enabled = True

End Sub

Private Sub Cmd_Ultimo_Click()

If Tabela_Atendimento.EOF = False Then
   Tabela_Atendimento.MoveLast
   Call Mostra_Registro
ElseIf Tabela_Atendimento.BOF = True _
  And Tabela_Atendimento.EOF = True Then
  MsgBox "N�o h� dados no Arquivo!", , "Sem Dados !"
End If

End Sub

Private Sub Form_Load()

Dim hMenu As Long
Dim lItemCount As Long

hMenu = GetSystemMenu(Me.hWnd, 0)
If hMenu Then
   lItemCount = GetMenuItemCount(hMenu)
   Call RemoveMenu(hMenu, lItemCount - 1, MF_REMOVE Or _
   MF_BYPOSITION)
   Call RemoveMenu(hMenu, lItemCount - 2, MF_REMOVE Or _
   MF_BYPOSITION)
   Call DrawMenuBar(Me.hWnd)
End If

Form_Xsol_05.Top = (Screen.Height - Form_Xsol_05.Height) / 2
Form_Xsol_05.Left = (Screen.Width - Form_Xsol_05.Width) / 2

Call Arquivos_Dados

Set W_DB = New Connection

Set Tabela_Tecnicos = New Recordset

W_DB.Mode = adModeReadWrite

W_DB.Open "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" & W_DBname & ";"

Tabela_Tecnicos.Open "select * from Tecnico Order By Nome ", W_DB, adOpenStatic, adLockOptimistic

Set Tabela_Clientes = New Recordset
Tabela_Clientes.Open "select * from Clientes where Codigo=" & Cod_Cli, W_DB, adOpenStatic, adLockOptimistic

Set Tabela_Visitas = New Recordset
Tabela_Visitas.Open "select * from Visitas where Cod_Cliente=" & Cod_Cli, W_DB, adOpenStatic, adLockOptimistic

Set Tabela_Servicos = New Recordset
Tabela_Servicos.Open "select Tipo_Serv from Servico Order By Tipo_Serv ", W_DB, adOpenStatic, adLockOptimistic

Set Tabela_Atendimento = New Recordset

Tabela_Atendimento.Open "select * from Atendimento where Cod_Cliente=" & Cod_Cli, W_DB, adOpenStatic, adLockOptimistic

Call Trava_Registro
Call Mostra_Registro

Text_NomeCli.Locked = True
Text_Tecnico.Locked = True

End Sub

Sub Lista_Tecnico()

Dim Cod_Tec As Integer
Dim Nome_Tec As String

If Tabela_Tecnicos.BOF = True And Tabela_Tecnicos.EOF = True Then
Else
    Tabela_Tecnicos.MoveFirst
    Combo_Tecnico.Clear
    Do While Not Tabela_Tecnicos.EOF
       DoEvents
       Cod_Tec = Tabela_Tecnicos.Fields("Codigo")
       Nome_Tec = Tabela_Tecnicos.Fields("Nome")
       Combo_Tecnico.AddItem (Cod_Tec) & ("   -   ") & (Nome_Tec)
       Tabela_Tecnicos.MoveNext
    Loop
End If

End Sub

Sub Mostra_Tecnico()

Dim Cod_Tec As Integer
Dim X_Cod_Tec As Integer

X_Cod_Tec = IIf(IsNull(Tabela_Atendimento.Fields("Cod_Tecnico")), "", Tabela_Atendimento.Fields("Cod_Tecnico"))

If Tabela_Tecnicos.BOF = True And Tabela_Tecnicos.EOF = True Then
Else
    Tabela_Tecnicos.MoveFirst
    Text_Tecnico.Text = ""
    Do While Not Tabela_Tecnicos.EOF And (Cod_Tec <> X_Cod_Tec)
       DoEvents
       Cod_Tec = Tabela_Tecnicos.Fields("Codigo")
       If Cod_Tec <> X_Cod_Tec Then
          Tabela_Tecnicos.MoveNext
       End If
    Loop
    Text_Tecnico = UCase(Tabela_Tecnicos.Fields("Nome"))
       
End If

End Sub

Sub Lista_Servico()

If Tabela_Servicos.BOF = True And Tabela_Servicos.EOF = True Then
Else
    Tabela_Servicos.MoveFirst
    Combo_Servico.Clear
    Do While Not Tabela_Servicos.EOF
       DoEvents
       Combo_Servico.AddItem Tabela_Servicos.Fields("Tipo_Serv")
       Tabela_Servicos.MoveNext
    Loop
End If

End Sub

Sub Lista_Ficha()

Combo_Ficha.Clear
Combo_Ficha.AddItem "ASSISTENCIA"
Combo_Ficha.AddItem "INSTALA�AO"
Combo_Ficha.AddItem "VISTORIA"

End Sub

Private Sub GravaRegistros()

Dim Cod_Tec As Integer

Cod_Tec = CInt(Mid$(Combo_Tecnico.Text, 1, 3))
Tabela_Atendimento.Fields("Cod_Tecnico").Value = Cod_Tec

Tabela_Atendimento.Fields("Cod_Cliente").Value = Cod_Cli

Tabela_Atendimento.Fields("Tipo_Serv").Value = "ABERTO"

If Trim(Combo_Servico.Text) = "" Then
   Tabela_Atendimento.Fields("Tipo_Serv").Value = Null
Else
   Tabela_Atendimento.Fields("Tipo_Serv").Value = Combo_Servico.Text
End If

If Trim(Combo_Ficha.Text) = "" Then
   Tabela_Atendimento.Fields("Ficha").Value = Null
Else
   Tabela_Atendimento.Fields("Ficha").Value = Combo_Ficha.Text
End If

If Trim(val(Text_Valor.Text)) = "" Then
   Tabela_Atendimento.Fields("Valor_Serv").Value = Null
Else
   Tabela_Atendimento.Fields("Valor_Serv").Value = cvInt(Text_Valor.Text)
End If

If Trim(val(Mask_Dt_Serv.Text)) = "" Then
   Tabela_Atendimento.Fields("Dt_Atend_Serv").Value = Null
Else
   'Tabela_Atendimento.Fields("Dt_Atend_Serv").Value = vData(Text_Dt_Serv.Text)
   Tabela_Atendimento.Fields("Dt_Atend_Serv").Value = vData(Mask_Dt_Serv.Text)
End If

Tabela_Atendimento.Fields("Dt_Atend").Value = Date
Tabela_Atendimento.Fields("Status").Value = "ABERTO"

If Generate_Next_Visit(Combo_Servico.Text) Then
    W_DB.Execute "UPDATE Visitas SET Dt_Expiracao = Now() WHERE Dt_Expiracao IS NULL AND cod_cliente = " + Str(Cod_Cli)

    Tabela_Visitas.Fields("Dt_Prox_Visita").Value = DateAdd("yyyy", 1, vData(Mask_Dt_Serv.Text))
    Tabela_Visitas.Fields("cod_cliente").Value = Cod_Cli

    Tabela_Visitas.Fields("dt_criacao").Value = Now
End If

End Sub

Private Function Generate_Next_Visit(tipoServ As String) As Boolean
    Generate_Next_Visit = (tipoServ = "INSTALA��O CONJUNTO AQUECIMENTO" Or tipoServ = "INSTALA��O PISCINA" Or tipoServ = "MANUTEN��O PREVENTIVA")
End Function

Sub DesabilitaNavegacao()
   
   Cmd_Fechar.enabled = False
   Cmd_Primeiro.enabled = False
   Cmd_Anterior.enabled = False
   Cmd_Proximo.enabled = False
   Cmd_Ultimo.enabled = False

End Sub

Sub Destrava_Registro()

Combo_Tecnico.Visible = True
Combo_Servico.Visible = True
Combo_Ficha.Visible = True

Text_Tecnico_Cod.Locked = False
Text_Serv_Solic.Locked = False
Mask_Dt_Serv.enabled = True
Text_Ficha.Locked = False
Text_Valor.Locked = False

End Sub

Sub Trava_Registro()

Cmd_Salva.enabled = False
Combo_Tecnico.Visible = False
Combo_Servico.Visible = False
Combo_Ficha.Visible = False

Text_Tecnico_Cod.Locked = True
Text_Serv_Solic.Locked = True
Mask_Dt_Serv.enabled = False
Text_Ficha.Locked = True
Text_Valor.Locked = True

End Sub

Sub Mostra_Registro()

If (Tabela_Atendimento.EOF = True) Or (Tabela_Atendimento.BOF = True) Then
   Exit Sub
End If

Text_OS.Text = IIf(IsNull(Tabela_Atendimento.Fields("Codigo")), "", Tabela_Atendimento.Fields("Codigo"))
Text_NomeCli.Text = Nome_Cli_Atend
Text_Tecnico_Cod.Text = IIf(IsNull(Tabela_Atendimento.Fields("Cod_Tecnico")), "", Tabela_Atendimento.Fields("Cod_Tecnico"))
Call Mostra_Tecnico
Text_Serv_Solic = IIf(IsNull(Tabela_Atendimento.Fields("Tipo_Serv")), "", Tabela_Atendimento.Fields("Tipo_Serv"))
Text_Valor.Text = FormatCurrency(IIf(IsNull(Tabela_Atendimento.Fields("Valor_Serv")), "", Tabela_Atendimento.Fields("Valor_Serv")))
Mask_Dt_Serv = IIf(IsNull(Tabela_Atendimento.Fields("Dt_Atend_Serv")), "", Tabela_Atendimento.Fields("Dt_Atend_Serv"))
Text_Ficha.Text = IIf(IsNull(Tabela_Atendimento.Fields("Ficha")), "", Tabela_Atendimento.Fields("Ficha"))
Text_Status.Text = IIf(IsNull(Tabela_Atendimento.Fields("Status")), "", Tabela_Atendimento.Fields("Status"))


End Sub

Sub LimpaControles()

Text_OS.Text = ""
Text_Tecnico_Cod.Text = ""
Text_Serv_Solic.Text = ""
Mask_Dt_Serv.Text = "__/__/____"
Text_Ficha.Text = ""
Text_Valor.Text = ""

End Sub

Sub HabilitaNavegacao()

   Cmd_Fechar.enabled = True
   Cmd_Primeiro.enabled = True
   Cmd_Anterior.enabled = True
   Cmd_Proximo.enabled = True
   Cmd_Ultimo.enabled = True

End Sub

Sub Ficha_Vistoria_Pisc()

'Printer.PaperSize = 9
Printer.PaintPicture Image1.Picture, 0, 0
Printer.FontName = "Copperplate Gothic Light"
Printer.FontSize = 10
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.FontSize = 12
Printer.FontBold = True
Printer.Print "                                     FICHA DE VISTORIA T�CNICA (PISCINA)"
Printer.FontBold = False
Printer.Print
Printer.FontSize = 10
Printer.Print
Printer.FontBold = True
Printer.Print Spc(3); "ITENS INDISPENS�VEIS:"
Printer.FontBold = False
Printer.Print
Call Print_Cliente
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "1) CONFORME CONSULTORIA REALIZADA NO LOCAL ONDE SER� REALIZADO O"
Printer.Print Spc(3); "SERVI�O, DEFINE-SE NESTA, AS PROVID�NCIAS A SEREM TOMADAS PELO CLIENTE"
Printer.Print Spc(3); "E OBSERVA��ES ADICIONAIS"
Printer.FontBold = True
Printer.Print Spc(3); "DIMENS�ES E CARACTER�STCAS DA PISCINA:"
Printer.FontBold = False
Printer.Print Spc(3); "* PROFUNDIDADE:_______________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* COMPRIMENTO:________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* MATERIAL UTILIZANDO P/ CONFEC��O DA PISCINA:________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* � POSSIVEL INSTALAR RETORNO EM COBRE: (  ) SIM   (  ) N�O"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* POSSUI AQUECIMENTO PARA PISC.: (  ) SIM (  ) N�O TIPO:______________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* PISCINA COM RETORNO: (  ) COBRE (  ) PVC (  ) AQUATERM"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* ETAPA DA PISCINA: (  ) PROJETO (  ) ADAMEN. (  ) PRONTA (  ) REFORMA"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* RALO DE FUNDO: (  ) EXCLUSIVO (  ) COMPARTILHADO"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* PISCINA (  ) COBERTA (  ) DESCOBERTA"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* INCID�NCIA DE SOMBRA NOS COLETORES: (  ) ALTA (  ) M�IDA (  ) BAIXA"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* CROQUI NO VERSO: (DETALHES)"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "ORIGEM DA �GUA:"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(  ) COMPANHIA RESPONS�VEL PELO ABASTECIMENTO"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(  ) �GUA DE PO�O"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(  ) CAMINH�O TANQUE"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(  ) �GUA TRATADA PELO CONDOM�NIO"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "TIPO DE TRATAMENTO A SER ULTILIZADO:"
Printer.FontBold = False
Printer.Print Spc(3); "COMENTE:______________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "MESS�ES T�CNICAS CONFORME CROQUI:"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* DIST�NCIA HORIZONTAL ENTRE PISCINA./ COLETORES:_____________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* DIST�NCIA HORIZONTAL ENTRE CASA DE M�QUINAS. / PISCINA:_____________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* DIST�NCIA HORIZONTAL ENTRE CASA DE M�QUINAS. / COLETORES:___________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* DIST�NCIA VERTICAL ENTRE PISCINA. / COLETORES: _____________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* DIST�NCIA VERTICAL ENTRE CASA DE M�Q. / COLETORES:__________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* DIST�NCIA VERTICAL ENTRE CASA DE M�Q. / PISCINA:____________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* LARGURA DO TELHADO:_________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* COMPRIMENTO DO TELHADO:_____________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* INCLINA��O DO TELHADO:______________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* MATERIAL QUE � FEITO O TELHADO:_____________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* B�SSOLA:____________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* ALTURA DOS DISPOSITIVOS DE RETORNO:_________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "TIPO DE CASA DE M�QUINA:"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(  ) ACIMA DA PISCINA"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(  ) ABAIXO DA PISCINA:_______________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(  ) NO N�VEL DO FUNDO PISCINA:_______________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(  ) MEIA ALTURA DA PISCINA:__________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "DESCRI��O DO EQUIPAMENTO:"
Printer.FontBold = False
Printer.Print Spc(3); "* COLETOR"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "MODELO:_______________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "QUANTIDADE:___________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "OBSERVA��ES GERAIS:"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "IMPORTANTE:"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "LISTA DE MATERIAL SER� FEITA MEDIANTE O CROQUI E VISTORIA FEITA NO LOCAL."
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print
Printer.Print
Printer.Print
Printer.Print Spc(3); "____________________________________"
Printer.Print Spc(3); "        CLIENTE OU RESPONSAVEL      "
Printer.Print
Printer.Print Spc(3); "____________________________________"; Spc(5); "___________________,____ DE _______________DE__________"
Printer.Print Spc(3); "        VENDEDOR RESPONS�VEL        "
Printer.Print
Printer.Print Spc(3); "____________________________________"
Printer.Print Spc(3); "        T�CNICO RESPONS�VEL         "
Printer.Print
Printer.EndDoc

End Sub


Sub Ficha_Vistoria_Resid_Ind()

''Printer.PaperSize = 9
Printer.PaintPicture Image1.Picture, 0, 0
Printer.FontName = "Copperplate Gothic Light"
Printer.FontSize = 10
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.FontBold = True
Printer.FontSize = 12
Printer.Print Spc(30); "FICHA DE VISTORIA T�CNICA"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "ITENS INDISPENS�VEIS:"
Printer.FontBold = False
Printer.Print
Call Print_Cliente
Printer.Print
Printer.Print Spc(3); "1) CONFORME CONSULTORIA REALIZADA NO LOCAL ONDE SER� REALIZADO O"
Printer.Print Spc(3); "SERVI�O, DEFINE-SE NESTA, AS PROVID�NCIAS A SEREM TOMADA PELO CLIENTE"
Printer.Print Spc(3); "E OBSERVA��ES ADICIONAIS."
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "FLANGE (   )SIM (   )N�O VALOR:_______________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "* SUPORTE P/ BOILER: (   ) SIM (   ) N�O  VALOR:______________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "** SUPORTE P/ CAIXA D�GUA: (   )SIM (   )N�O  VALOR:__________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "SUPORTE P/ COLETORES: (   )SIM (   ) N�O  VALOR:______________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "BARRILHETE: (   ) SIM (   ) N�O QUANTID.____  VALOR:__________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "MATERIAL: (   ) SIM (   ) N�O VALOR ATUALIZADO:_______________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "*** PARTE EL�TRICA P/ SISTEMA: (   ) SIM (   ) N�O VALOR:_____________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "OBSERVA��ES:"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(5); "� A INSTALA��O DEVER� SER AGENDA SOMENTE AP�S A CONCLUS�O DE"
Printer.Print Spc(3); "TODOS A PROVIDENCIAS A SEREM TOMADAS ACIMA."
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(5); "� CASO O T�CNICO (NO DIA DA INSTALA��O DO SISTEMA), CONSTATE ALGUMA"
Printer.Print Spc(3); "IRREGULARIDADE NAS PROVID�NCIAS ACIMA DESCRITAS E QUE O IMPE�A DE"
Printer.Print Spc(3); "EXECUTAR OS SERVI�OS, O CLIENTE ESTAR� COMPREMETIDO A PAGAR COMO"
Printer.Print Spc(3); "MULTA O VALOR DE R$ 180,00, DESTINADO AO RESSARCIMENTO DAS DESPESAS"
Printer.Print Spc(3); "DE DESLOCAMENTO E HORA T�CNICA."
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "INFORMA��ES REFERENTE � INSTALA��O E SERVI�OS ADICIONAIS:"
Printer.FontItalic = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "VALOR DA INSTALA��O: R$______________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "SERVI�OS ADICIONAIS: R$______________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "VALOR TOTAL: R$______________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print Spc(3); "________________________________________________________,_________DE _______________________DE _________________"
Printer.Print
Printer.Print
Printer.Print
Printer.Print Spc(3); "________________________________"; Spc(25); "__________________________________________________"
Printer.Print Spc(3); "  CLIENTE OU RESPONS�VEL   "; Spc(27); "T�CNICO RESPONS�VEL PELO SERVI�O"

Printer.Print
Printer.FontBold = True
Printer.Print Spc(3); "(*),(**),(***): CROQUIS RESPECTIVOS NO VERSO"
Printer.FontBold = False
Printer.EndDoc

End Sub

Sub Orcamento()

''Printer.PaperSize = 9
Printer.PaintPicture Image1.Picture, 0, 0
Printer.FontName = "Copperplate Gothic Light"
Printer.FontSize = 10
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.FontSize = 12
Printer.FontBold = True
Printer.Print Spc(12); "OR�AMENTO REFERENTE A (SERVI�OS PRESTADOS)"
Printer.FontBold = False
Printer.FontSize = 10
Printer.Print
Call Print_Cliente
Printer.FontBold = True
Printer.Print Spc(3); "EQUIPAMENTOS"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "� PISCINA:(   ) SIM (   ) N�O"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "� BOILER MODELO___________ LITRAG._________ QUANT.__________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "� COLETORES: MODELO_________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "� CDT / CONTROLADORES SIMILARES: MARCA.______________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "MODELO________________________________QUANT.________________"
Printer.Print Spc(3); "SERVI�OS ADICIONAIS"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "� COMENTE:____________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "VALOR:________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "VALORES REFERENTE A SERVI�OS PRESTADOS"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "VALOR TOTAL:________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "PAGAMENTO"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(   ) BOLETO BANC�RIO"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(   ) CHEQUE  (   ) � VISTA (   ) DIVIDIDO QUANT. VEZES:_____"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "(   ) DINHEIRO"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "OBSERVA��O:"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "� TODOS OS SERVI�OS PRESTADOS DEVER�O SER PAGOS AP�S O T�RMINO DO  SERVI�O, TENDO"
Printer.Print Spc(3); "ASSIM GARANTIA DE _________, AFIM DE SOLUCIONAR ALGUM POSSIVEL PROBLEMA QUE VENHA POR "
Printer.Print Spc(3); "VENTURA APARECER."
Printer.Print Spc(3); "� A XSOL N�O � RESPONS�VEL PELA QUALIDADE E ENTREGA DOS PRODUTOS ADQUIRIDOS"
Printer.Print Spc(3); "DIRETAMENTE PELO CLIENTE"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print
Printer.Print
Printer.Print Spc(3); "_____________________________________________________,_______DE_______________________DE__________________"
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print Spc(3); "______________________________________"; Spc(27); "__________________________________________"
Printer.Print Spc(3); "          T�CNICO RESPONS�VEL"; Spc(32); "RESPONS�VEL - CIENTE E DE ACORDO  "

Printer.EndDoc

End Sub

Sub Print_Cliente()
'******** Variaveis do Cliente ******************************
Dim Print_Codigo As String
Dim Print_NomeCli As String, Print_EndCli As String
Dim Print_BairroCli As String, Print_CepCli As String
Dim Print_Ref As String
Dim Print_CidadeCli As String, Print_TelResCli As String
Dim Print_TelComCli As String, Print_CelularCli As String

'*****************************************************************************************************************

Print_Codigo = IIf(IsNull(Tabela_Clientes.Fields("codigo")), "", Tabela_Clientes.Fields("codigo"))

Print_NomeCli = IIf(IsNull(Tabela_Clientes.Fields("Nome_Cli")), "", Tabela_Clientes.Fields("Nome_Cli"))

Print_EndCli = IIf(IsNull(Tabela_Clientes.Fields("End")), "", Tabela_Clientes.Fields("End"))

Print_BairroCli = IIf(IsNull(Tabela_Clientes.Fields("Bairro")), "", Tabela_Clientes.Fields("Bairro"))

Print_CepCli = IIf(IsNull(Tabela_Clientes.Fields("Cep")), "", Tabela_Clientes.Fields("Cep"))

Print_Ref = IIf(IsNull(Tabela_Clientes.Fields("Ref")), "", Tabela_Clientes.Fields("Ref"))

Print_CidadeCli = IIf(IsNull(Tabela_Clientes.Fields("Cidade")), "", Tabela_Clientes.Fields("Cidade"))

Print_TelResCli = IIf(IsNull(Tabela_Clientes.Fields("Fone_Res")), "", Tabela_Clientes.Fields("Fone_Res"))

Print_TelComCli = IIf(IsNull(Tabela_Clientes.Fields("Fone_Com")), "", Tabela_Clientes.Fields("Fone_Com"))

Print_CelularCli = IIf(IsNull(Tabela_Clientes.Fields("Fone_Celular")), "", Tabela_Clientes.Fields("Fone_Celular"))

'*****************************************************************************************************************

Printer.FontSize = 10

Printer.Print
Call Print_Label("C�DIGO DO CLIENTE")
Call Print_Val(Print_Codigo, True)
Call Print_Label("NOME DO CLIENTE")
Call Print_Val(Print_NomeCli, True)

Printer.Print

Call Print_Label("ENDERE�O")
Call Print_Val(Print_EndCli, True)

Call Print_Label("BAIRRO")
Call Print_Val(Print_BairroCli, True)

Call Print_Label("CEP")
Call Print_Val(Print_CepCli, True)

Call Print_Label("CIDADE")
Call Print_Val(Print_CidadeCli, True)
Printer.Print

Call Print_Label("REFER�NCIA")
Call Print_Val(Print_Ref, True)
Printer.Print

Call Print_Label("TEL. RES.")
Call Print_Val(Print_TelResCli, False)
Printer.Print Spc(5);
Call Print_Label("TEL. COM.")
Call Print_Val(Print_TelComCli, False)
Printer.Print Spc(5);
Call Print_Label("CELULAR")
Call Print_Val(Print_CelularCli, True)

Printer.ForeColor = vbBlack
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"

End Sub

Sub Print_Header()

Printer.PaintPicture Image1.Picture, 0, 0
Printer.Print
Printer.Print
Printer.FontBold = True
Printer.ForeColor = vbBlack

Printer.FontSize = 10
Printer.Print Spc(70); "FONES:";

Printer.FontSize = 6
Printer.Print Spc(2);
Printer.FontSize = 11
Printer.Print "(11)   2116-6100"
Printer.FontSize = 10
Printer.Print Spc(79);
Printer.FontSize = 11
Printer.Print "(11)   2301-3651"
Printer.FontSize = 10
Printer.Print Spc(79);
Printer.FontSize = 11
Printer.Print "(11) 94077-7778"

Printer.FontBold = False
End Sub

Sub Print_Title(report_Type As Integer)

Printer.Print
Printer.FontSize = 12
Printer.FontBold = True
If report_Type = 1 Then
    Printer.Print Spc(30); "FICHA DE INSTALA��O"
ElseIf report_Type = 2 Then
    Printer.Print Spc(27); "FICHA DE INSTALA��O (PISCINA)"
Else
    Printer.Print Spc(24); "FICHA DE ASSIST�NCIA T�CNICA"
End If
Printer.FontBold = False

End Sub

Sub Print_OS()
'******** Variaveis do Cliente ******************************

Dim Print_OS As String
Dim Print_DtServ As String

'*****************************************************************************************************************

Print_OS = IIf(IsNull(Tabela_Atendimento.Fields("Codigo")), "", Tabela_Atendimento.Fields("Codigo"))

Print_DtServ = IIf(IsNull(Tabela_Atendimento.Fields("Dt_Atend_Serv")), "", Tabela_Atendimento.Fields("Dt_Atend_Serv"))

'*****************************************************************************************************************
Printer.FontSize = 12

Printer.Print
Call Print_Label("OS")
Call Print_Val(Print_OS, False)
Printer.FontSize = 10
Printer.Print Spc(48);

Call Print_Label("DATA DO SERVI�O")
Call Print_Val(Print_DtServ, True)

Printer.ForeColor = vbBlack
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"

End Sub

Sub Print_Executante()
'******** Variaveis do Cliente ******************************

Dim Print_EmpExec As String
Dim Print_Nome As String, Print_Atendente As String

'*****************************************************************************************************************

Print_EmpExec = IIf(IsNull(Tabela_Tecnicos.Fields("Razao")), "", Tabela_Tecnicos.Fields("Razao"))

Print_Nome = IIf(IsNull(Tabela_Tecnicos.Fields("Nome")), "", Tabela_Tecnicos.Fields("Nome"))

Print_Atendente = IIf(IsNull(Tabela_Clientes.Fields("Atendente")), "", Tabela_Clientes.Fields("Atendente"))

'*****************************************************************************************************************
Printer.FontSize = 10
Printer.Print

Call Print_Label("EMPRESA EXECUTANTE")
Call Print_Val(Print_EmpExec, True)

Call Print_Label("T�CNICO RESPONS�VEL")
Call Print_Val(Print_Nome, True)

Call Print_Label("ATENDENTE")
Call Print_Val(Print_Atendente, True)

Printer.ForeColor = vbBlack
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"

End Sub
Sub Print_Equipamento(report_Type As Integer)

Dim Print_Equip As String, Print_ValServ As String, Print_TipoServ As String

'*****************************************************************************************************************

Print_Equip = IIf(IsNull(Tabela_Clientes.Fields("Tipo_Eq_Mod")), "", Tabela_Clientes.Fields("Tipo_Eq_Mod"))

Print_ValServ = IIf(IsNull(Tabela_Atendimento.Fields("Valor_Serv")), "", "R$ " + FormatNumber(Tabela_Atendimento.Fields("Valor_Serv"), 2))

Print_TipoServ = IIf(IsNull(Tabela_Atendimento.Fields("Tipo_Serv")), "", Tabela_Atendimento.Fields("Tipo_Serv"))

'*****************************************************************************************************************
Printer.FontSize = 10
Printer.Print

If report_Type <> 2 Then
    Call Print_Label("TIPO DE EQUIPAMENTO")
    Call Print_Val(Print_Equip, True)
Else
    Call Print_Label("N� DE COLETORES")
    Printer.Print
End If

If report_Type = 3 Then
    Call Print_Label("TIPO DE SERVI�O")
    Call Print_Val(Print_TipoServ, True)
End If

Call Print_Label("VALOR DA INSTALA��O")
Call Print_Val(Print_ValServ, True)

Printer.ForeColor = vbBlack
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"

End Sub

Sub Print_Label(Lbl As String)

Printer.FontBold = True
Printer.ForeColor = vbBlack
Printer.Print Spc(3); Lbl + ": ";

End Sub

Sub Print_Val(val As String, new_Line As Boolean)

Printer.FontBold = False
Printer.ForeColor = RGB(0, 0, 255)
Printer.Print val;
If new_Line Then
    Printer.Print
End If

End Sub

Sub Print_Importante(report_Type As Integer)

Printer.FontBold = True
Printer.Print

If report_Type <> 3 Then
    Printer.ForeColor = vbRed
    Printer.Print Spc(3); "IMPORTANTE:"
    Printer.FontBold = False
    Printer.ForeColor = RGB(170, 60, 57)
Else
    Printer.ForeColor = vbBlack
    Printer.Print Spc(3); "IMPORTANTE:";
    Printer.FontBold = False
End If

If report_Type = 1 Then
    Printer.Print Spc(3); "MANTER A V�LVULA ANTI-CONGELAMENTO (DISPOSITIVO QUE PROTEGE OS COLETORES CONTRA"
    Printer.Print Spc(3); "CONGELAMENTO EM GEADAS), SEMPRE ENERGIZADA. CASO NO ATO DA INSTALA��O O T�CNICO N�O "
    Printer.Print Spc(3); "ENCONTRE A FIA��O DE ALIMENTA��O DA MESMA (ITEM PEDIDO EM VISTORIA T�CNICA), O "
    Printer.Print Spc(3); "CLIENTE FICA CIENTE QUE O RETORNO SER� COBRADO UMA TAXA REFERENTE A UMA VISITA "
    Printer.Print Spc(3); "T�CNICA. O MESMO SE APLICA COM OS DEMAIS ITENS SOLICITADOS NA VISTORIA."
ElseIf report_Type = 2 Then
    Printer.Print Spc(3); "SEMPRE MANTER O SISTEMA LIGADO JUNTAMENTE COM A CAPA T�RMICA, PARA QUE O MESMO "
    Printer.Print Spc(3); "ATINJA A TEMPERATURA DE CONTRATO 25� � 29 GRAUS."
    Printer.Print Spc(3); "QUALQUER TIPO DE MANUTEN��O NO SISTEMA DE AQUECIMENTO SOLAR DA PISCINA, �  "
    Printer.Print Spc(3); "ACONSELH�VEL SER EFETUADO APENAS POR PROFISSIONAIS QUALIFICADO DA XSOL."
Else
    Printer.Print ; "OS SERVI�OS EXECUTADOS PODER�O SER RECLAMADOS NO PRAZO DE "
    Printer.Print Spc(3); "03 MESES A CONTAR DA DATA DE SUA REALIZA��O."
    Printer.Print Spc(3); "AP�S ESTE PRAZO ENTENDE-SE QUE O PROBLEMA FOI SANADO E NOVAS SOLICITA��ES SER�O"
    Printer.Print Spc(3); "COBRADAS."
End If

Printer.ForeColor = vbBlack
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
End Sub

Sub Print_Garantia()

Printer.FontBold = True
Printer.ForeColor = vbBlack
Printer.Print
Printer.Print Spc(3); "GARANTIA DE INSTALA��O"
Printer.FontBold = False
Printer.Print Spc(3); "A INSTALA��O POSSUI 3 MESES DE GARANTIA A PARTIR DA DATA DE CONCLUS�O DA MESMA, E "
Printer.Print Spc(3); "COBRE: "
Printer.Print Spc(3); "* O N�O FUNCIONAMENTO DO SISTEMA, DECORRENTES A MOTIVOS DE INSTALA��O."
Printer.Print Spc(3); "* VAZAMENTO NOS CASOS DE INTERLIGA��O DO SISTEMA."
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"

End Sub

Sub Print_Lembrete()

Printer.FontBold = True
Printer.ForeColor = vbBlack
Printer.Print
Printer.FontBold = True
Printer.Print Spc(3); "LEMBRETE:"
Printer.FontBold = False
Printer.Print Spc(3); "COM O OBJETIVO DE SEMPRE MANTER A BOA PERFORMANCE DO SISTEMA, EXISTE A NECESSIDADE "
Printer.Print Spc(3); "DE NO M�XIMO 6 MESES SER REALIZADA UMA MANUTEN��O PREVENTIVA."
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"

End Sub

Sub Print_DataAssinatura(report_Type As Integer)

If report_Type <> 3 Then
    Printer.Print
    Printer.Print
End If
Printer.Print
Printer.Print
Printer.Print Spc(3); "________________________________________________________ , _________ DE _______________________ DE ______________"

If report_Type <> 3 Then
    Printer.Print
    Printer.Print
End If
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print
Printer.Print Spc(3); "________________________________"; Spc(25); "__________________________________________________"
Printer.Print Spc(3); "  CLIENTE OU RESPONS�VEL   "; Spc(27); "T�CNICO RESPONS�VEL PELO SERVI�O"

End Sub

Sub Print_Relatorio()

Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.FontBold = True
Printer.Print Spc(3); "RELAT�RIO:"
Printer.FontBold = False
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
Printer.FontSize = 6
Printer.Print
Printer.FontSize = 10
Printer.Print Spc(3); "______________________________________________________________________________________________________________________________"
End Sub

Sub Ficha(report_Type As Integer)

Printer.FontName = "Copperplate Gothic Light"

Call Print_Header

Printer.FontSize = 10
Printer.Print
Call Print_Title(report_Type)
Printer.Print

Call Print_OS
Call Print_Executante
Call Print_Cliente
Call Print_Equipamento(report_Type)
If report_Type = 3 Then
    Call Print_Relatorio
End If

Call Print_Importante(report_Type)

If report_Type <> 3 Then
    Call Print_Garantia
    Call Print_Lembrete
    Printer.Print
    Printer.Print
    Printer.Print
End If

Call Print_DataAssinatura(report_Type)

Printer.EndDoc

End Sub
